from pathlib import Path
import json,subprocess
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).parent;P=R/'project';O=R/'output';F='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
C=[(0,5,'СУТИЧКИ ПІД КИЄВОМ\nРЕАКЦІЯ БУДАНОВА','Петропавлівська Борщагівка',51),(5,10,'ПОШТОВХ — ЗАЯВИ\nПРО УТРИМАННЯ ЛЮДЕЙ','Йшлося про нібито незаконне утримання',48),(10,16,'ЗІБРАЛИСЯ ЛЮДИ\nПОЧАЛИСЯ СУТИЧКИ','Поліція заперечувала незаконне утримання',50),(16,22,'НГУ: ЦЕ ТИМЧАСОВИЙ\nПУНКТ ДИСЛОКАЦІЇ','Позиція Національної гвардії',47),(22,28,'НГУ ПОВІДОМИЛА\nПРО ТРАВМОВАНИХ ВІЙСЬКОВИХ','Чотирьох відправили до шпиталю',40),(28,37,'БУДАНОВ ЗАКЛИКАВ\nРОЗХОДИТИСЯ','За його словами, заручників у будинку немає',49),(37,44,'БУДАНОВ НАЗВАВ ПОДІЇ\nНЕПРИПУСТИМИМИ','Офіційна заява • 03.11.2026',47),(44,50,'СБУ: ТРЬОМ ФІГУРАНТАМ\nПОВІДОМИЛИ ПРО ПІДОЗРУ','Оновлення СБУ • 04.11.2026',45),(50,55,'ОКРЕМЕ ПРОВАДЖЕННЯ\nВЕДЕ ДБР','Підозра не означає доведеної вини',48)]
T=json.loads((P/'timeline.json').read_text());shots=T['shots']
def tm(s):return f'{int(s//3600)}:{int(s//60)%60:02}:{s%60:05.2f}'
head='''[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
ScaledBorderAndShadow: yes
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Main,DejaVu Sans,48,&H00FFFFFF,&H000000FF,&H0016240B,&H00000000,-1,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1
Style: Sub,DejaVu Sans,32,&H00E9E0D7,&H000000FF,&H0016240B,&H00000000,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
lines=[]
for a,b,title,sub,size in C:
 while max(ImageFont.truetype(F,size).getlength(x) for x in title.splitlines())>815:size-=1
 ss=32
 while ImageFont.truetype(F,ss).getlength(sub)>810:ss-=1
 title=title.replace('\n',r'\N');lines.append(f'Dialogue: 2,{tm(a)},{tm(b)},Main,,0,0,0,,{{\\move(90,1390,90,1360,0,220)\\fad(110,80)\\fs{size}}}{title}');lines.append(f'Dialogue: 2,{tm(a)},{tm(b)},Sub,,0,0,0,,{{\\pos(90,1530)\\fad(140,80)\\fs{ss}}}{sub}')
for s in shots:
 a=s['timeline_start'];b=a+s['timeline_duration'];label=s['label'];fs=32
 if label=='КАДРИ МІСЦЯ ПОДІЙ':label='КАДРИ З РЕПОРТАЖУ • 03.11.2026'
 while ImageFont.truetype(F,fs).getlength(label)>830:fs-=1
 lines.append(f'Dialogue: 2,{tm(a)},{tm(b)},Sub,,0,0,0,,{{\\pos(82,343)\\fs{fs}\\fad(50,40)}}{label}')
(P/'headlines.ass').write_text(head+'\n'.join(lines)+'\n')
im=Image.new('RGBA',(1080,1920));d=ImageDraw.Draw(im)
for y in range(430):d.line((0,y,1080,y),fill=(3,10,25,round(160*(1-y/430))))
for y in range(1160,1920):d.line((0,y,1080,y),fill=(3,10,25,round(min(215,(y-1160)*.42))))
d.rounded_rectangle((64,214,218,274),radius=5,fill=(199,30,54,255));d.text((82,223),'NEWS',font=ImageFont.truetype(F,34),fill='white');d.text((238,231),'КИЇВЩИНА',font=ImageFont.truetype(F,27),fill='white');d.text((754,232),'02.11.2026',font=ImageFont.truetype(F,27),fill='white')
d.rounded_rectangle((64,321,944,391),radius=7,fill=(4,17,37,224));d.rounded_rectangle((64,1320,944,1620),radius=10,fill=(5,18,39,235));d.rectangle((64,1320,74,1620),fill=(212,35,59));im.save(P/'layout.png')
args=['ffmpeg','-v','warning','-y','-filter_complex_threads','1']
for i in range(len(shots)):args+=['-threads','1','-i',str(R/'clips'/f'{i:02d}.mp4')]
args+=['-loop','1','-i',str(P/'layout.png')];g=[]
for i in range(len(shots)):g.append(f'[{i}:v]setpts=PTS-STARTPTS,fps=30,settb=1/30,format=yuv420p[v{i}]')
prev='v0'
for i in range(1,len(shots)):
 out=f'x{i}';g.append(f'[{prev}][v{i}]xfade=transition=fade:duration=0.133333333:offset={shots[i]["timeline_start"]},fps=30,settb=1/30[{out}]');prev=out
g.append(f'[{prev}][{len(shots)}:v]overlay=0:0,ass={P}/headlines.ass,format=yuv420p[out]');(P/'filter.ffscript').write_text(';\n'.join(g))
args+=['-filter_complex_script',str(P/'filter.ffscript'),'-map','[out]','-an','-frames:v','1650','-c:v','libx264','-profile:v','baseline','-level:v','4.0','-preset','fast','-crf','23','-maxrate','6500k','-bufsize','13000k','-threads','3','-pix_fmt','yuv420p','-map_metadata','-1','-movflags','+faststart',str(O/'BUDANOV-2026-11-02-55s-SILENT.mp4')]
with (P/'render.log').open('w') as f:subprocess.run(args,stdout=f,stderr=f,check=True)
print('export complete',flush=True)
