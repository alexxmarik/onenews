from pathlib import Path
import json,subprocess,concurrent.futures
R=Path(__file__).parent
for x in ['project','clips','output','review']:(R/x).mkdir(exist_ok=True)
old=Path('/workspace/budanov-2026-11-02/originals')
SOURCES={'report':R/'originals/rferl-report.mp4','crowd':old/'glavcom176699-0.mp4','official':old/'official-address-2026-11-03.MP4'}
S=[('official',0,2.5,'ОФІЦІЙНИЙ КОМЕНТАР • 03.11.2026'),('crowd',0,2.5,'КАДРИ ПОДІЇ • 02.11.2026'),('report',.3,2.5,'ПІСЛЯ СУТИЧОК • 03.11.2026'),('report',10.3,2.5,'КАДРИ МІСЦЯ ПОДІЙ'),('crowd',4,3,'КАДРИ ПОДІЇ • 02.11.2026'),('crowd',8,3,'КАДРИ ПОДІЇ • 02.11.2026'),('report',174.5,3,'КАДРИ МІСЦЯ ПОДІЙ'),('report',192,3,'КАДРИ ПОДІЇ • 02.11.2026'),('report',180.3,3,'КАДРИ МІСЦЯ ПОДІЙ'),('crowd',12,3,'КАДРИ ПОДІЇ • 02.11.2026'),('report',207,2.5,'БУДАНОВ НА МІСЦІ • 02.11.2026'),('report',257,3.5,'СПІЛКУВАННЯ З ПРИСУТНІМИ • 02.11.2026'),('crowd',18,3,'КАДРИ ПОДІЇ • 02.11.2026'),('official',8,3.5,'ОФІЦІЙНИЙ КОМЕНТАР • 03.11.2026'),('official',16,3.5,'ОФІЦІЙНИЙ КОМЕНТАР • 03.11.2026'),('report',202,3,'КАДРИ МІСЦЯ ПОДІЙ'),('report',340.5,3,'КАДРИ МІСЦЯ ПОДІЙ'),('report',345.3,2.5,'КАДРИ МІСЦЯ ПОДІЙ'),('crowd',23,2.5,'КАДРИ ПОДІЇ • 02.11.2026')]
assert sum(x[2] for x in S)==55
MASKS={'report':[(70,20,240,130),(0,900,1280,140)],'crowd':[(20,80,200,110)],'official':[]}
def make(i):
 name,start,dur,label=S[i];n=round(dur*30)+(4 if i<len(S)-1 else 0);g=[];last='0:v'
 for j,(x,y,w,h) in enumerate(MASKS[name]):
  g += [f'[{last}]split=2[b{j}][p{j}]',f'[p{j}]crop={w}:{h}:{x}:{y},boxblur=luma_radius=22:luma_power=3:chroma_radius=10:chroma_power=3[c{j}]',f'[b{j}][c{j}]overlay={x}:{y}[m{j}]'];last=f'm{j}'
 if name=='crowd':g+=[f'[{last}]fps=30,scale=1080:1920,setsar=1,eq=saturation=.9:contrast=1.02,format=yuv420p[out]']
 else:
  crop='crop=1440:1080:480:0,' if name=='report' and 206<start<261 else ''
  g += [f'[{last}]{crop}fps=30,setsar=1,split=2[b][f]','[b]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=26:2,eq=brightness=-.22:saturation=.75[bg]','[f]scale=1080:810:force_original_aspect_ratio=decrease,eq=saturation=.9:contrast=1.02[fg]','[bg][fg]overlay=(W-w)/2:430+(810-h)/2,format=yuv420p[out]']
 (R/'project'/f'normalize-{i:02d}.ffscript').write_text(';'.join(g))
 cmd=['ffmpeg','-v','error','-y','-threads','1','-ss',str(start),'-i',str(SOURCES[name]),'-filter_complex_threads','1','-filter_complex',';'.join(g),'-map','[out]','-an','-frames:v',str(n),'-c:v','libx264','-preset','veryfast','-crf','19','-threads','2','-pix_fmt','yuv420p',str(R/'clips'/f'{i:02d}.mp4')]
 p=subprocess.run(cmd,stderr=subprocess.PIPE)
 if p.returncode:raise RuntimeError(p.stderr.decode())
 print('clip',i,n,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:list(p.map(make,range(len(S))))
t=0;rows=[]
for i,(src,start,dur,label) in enumerate(S):rows.append(dict(index=i,source=src,source_start=start,timeline_start=t,timeline_duration=dur,label=label,frames=round(dur*30)+(4 if i<len(S)-1 else 0),blur_regions=MASKS[src]));t+=dur
(R/'project'/'timeline.json').write_text(json.dumps(dict(duration=55,fps=30,size=[1080,1920],shots=rows),ensure_ascii=False,indent=2))
