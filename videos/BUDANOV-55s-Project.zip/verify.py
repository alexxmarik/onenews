from pathlib import Path
import subprocess,json,concurrent.futures,hashlib
from PIL import Image,ImageDraw
R=Path(__file__).parent;O=R/'output';P=R/'project';v=O/'BUDANOV-2026-11-02-55s-SILENT.mp4'
times=[1,3.5,6,8.5,11.5,14.5,17.5,20.5,23.5,26.5,29,32,35.5,39,42,45.5,48.5,51,54]
def frame(t):
 p=R/'review'/f'{t}.png';subprocess.run(['ffmpeg','-v','error','-y','-threads','1','-ss',str(t),'-i',str(v),'-frames:v','1','-vf','scale=360:640','-threads','1',str(p)],check=True);im=Image.open(p).convert('RGB');ImageDraw.Draw(im).text((5,615),str(t),fill='yellow',stroke_width=1,stroke_fill='black');return im
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:ims=list(p.map(frame,times))
for k,group in enumerate([ims[:12],ims[12:]]):
 s=Image.new('RGB',(1440,640*((len(group)+3)//4)))
 for i,im in enumerate(group):s.paste(im,(i%4*360,i//4*640))
 s.save(R/'review'/f'contact-{k}.png')
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries','format=duration,size:stream=codec_type,codec_name,profile,width,height,pix_fmt,r_frame_rate,nb_read_frames','-of','json',str(v)]))
assert len(probe['streams'])==1
s=probe['streams'][0];assert (s['width'],s['height'],s['r_frame_rate'],s['codec_name'],s['nb_read_frames'])==(1080,1920,'30/1','h264','1650');assert float(probe['format']['duration'])==55
with (P/'validation.log').open('w') as f:subprocess.run(['ffmpeg','-hide_banner','-v','info','-xerror','-threads','2','-i',str(v),'-vf','blackdetect=d=0.12:pix_th=0.08','-f','null','-'],stdout=f,stderr=f,check=True)
assert 'black_start' not in (P/'validation.log').read_text()
probe['sha256']=hashlib.sha256(v.read_bytes()).hexdigest();probe['audio_streams']=0;probe['full_decode']='passed';probe['black_frames']='none detected';probe['ocr_batches']=69
(P/'QA.json').write_text(json.dumps(probe,indent=2));print(json.dumps(probe,indent=2),flush=True)
