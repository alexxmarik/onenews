from pathlib import Path
import subprocess,json,concurrent.futures,wave
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).parent
for d in ['project','clips','output']:(R/d).mkdir(exist_ok=True)
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
# Non-overlapping source ranges. Every shot is documentary archive, never incident footage.
shots=[
('nabu-office',13.15,2.5,'2017 • ОФІС НАБУ, ХАРКІВ',None),
('sbu-exterior',77,2.5,'2019 • БУДІВЛЯ СБУ','crop=650:550:0:0'),
('nabu-press',0.4,4,'14.09.2026 • ПРЕСКОМЕНТАР',None),
('nabu-press',6,4,'14.09.2026 • ПРЕСКОМЕНТАР',None),
('nabu-office',25.1,4,'2017 • ПРЕСКОНФЕРЕНЦІЯ НАБУ',None),
('nabu-trailer',50,4,'2018 • ФІЛЬМ ПРО НАБУ','crop=1920:800:0:140'),
('nabu-trailer',54.2,4,'2018 • ФІЛЬМ ПРО НАБУ','crop=1920:800:0:140'),
('sbu-profile',14,4,'2023 • АРХІВНИЙ БРИФІНГ СБУ',None),
('nabu-office',3.3,5,'2017 • ОФІС НАБУ, ХАРКІВ',None),
('sbu-exterior',79.7,5,'2019 • БУДІВЛЯ СБУ','crop=1000:300:0:0'),
('nabu-trailer',20.7,5,'2018 • ФІЛЬМ ПРО НАБУ','crop=1920:800:0:140'),
('nabu-trailer',11.7,5,'2018 • ФІЛЬМ ПРО НАБУ','crop=1920:800:0:140'),
('nabu-press',14,4.5,'14.09.2026 • ПРЕСКОМЕНТАР',None),
('nabu-office',29.5,4.5,'2017 • ПРЕСКОНФЕРЕНЦІЯ НАБУ',None),
]
assert sum(x[2] for x in shots)==58
# Use sources verbatim; audio is intentionally discarded at ingest.
def run(cmd):subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
def normalize(item):
 i,(name,start,dur,label,crop)=item;frames=round(dur*30)+(4 if i<len(shots)-1 else 0)
 im=Image.new('RGBA',(1080,1920));d=ImageDraw.Draw(im)
 d.rounded_rectangle((64,330,944,418),radius=8,fill=(4,14,31,235))
 d.text((84,342),'АРХІВ • НЕ КАДРИ ІНЦИДЕНТУ',font=ImageFont.truetype(FONT,27),fill='white')
 d.text((84,378),label,font=ImageFont.truetype(FONT,23),fill=(184,199,216))
 # Bottom credit remains in output even when the original frame has been reframed.
 credit='Відео: УНІАН / Telegram' if name=='nabu-press' else 'Відео: Радіо Свобода'
 d.text((66,1089),credit,font=ImageFont.truetype(FONT,25),fill=(225,232,241))
 im.save(R/'project'/f'archive-{i:02d}.png')
 # Blur source watermarks before reframing and background generation.
 regions=[]
 if name in ['nabu-office','sbu-exterior','sbu-profile']:regions.append((72,24,240,130))
 if name=='nabu-press':regions.append((620,0,228,110))
 if name=='nabu-office':regions.append((1450,968,470,112))
 if name=='sbu-profile':regions.append((0,900,360,110))
 filters=[]
 last='0:v'
 for j,(x,y,w,h) in enumerate(regions):
  filters.append(f'[{last}]split=2[base{j}][patch{j}]')
  filters.append(f'[patch{j}]crop={w}:{h}:{x}:{y},boxblur=20:3[blur{j}]')
  filters.append(f'[base{j}][blur{j}]overlay={x}:{y}[masked{j}]')
  last=f'masked{j}'
 prefix=';'.join(filters)+';' if filters else ''
 prefix+=f'[{last}]'+(crop+',' if crop else '')
 f=prefix+"fps=30,setsar=1,split=2[b][f];[b]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=30:2,eq=brightness=-0.28:saturation=0.65[bg];[f]scale=1080:780:force_original_aspect_ratio=decrease,eq=contrast=1.025:saturation=0.9[fg];[bg][fg]overlay=(W-w)/2:490+(780-h)/2,format=yuv420p[v];[v][1:v]overlay=0:0[out]"
 cmd=['ffmpeg','-v','error','-y','-threads','1','-ss',str(start),'-i',str(R/'originals'/(name+'.mp4')),'-i',str(R/'project'/f'archive-{i:02d}.png'),'-filter_complex_threads','1','-filter_complex',f,'-map','[out]','-an','-frames:v',str(frames),'-c:v','libx264','-preset','veryfast','-crf','19','-threads','2','-pix_fmt','yuv420p',str(R/'clips'/f'{i:02d}.mp4')]
 try:run(cmd)
 except subprocess.CalledProcessError as e:print(e.stderr.decode()[-2000:],flush=True);raise
 print('shot',i,frames,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:list(p.map(normalize,enumerate(shots)))
(R/'project'/'timeline.json').write_text(json.dumps({'duration':58,'fps':30,'size':[1080,1920],'shots':[dict(source=s[0],source_start=s[1],timeline_duration=s[2],archive_label=s[3],crop=s[4]) for s in shots],'transition_frames':4,'audio':'Digital silence only; replace VOICEOVER with your own recording.'},ensure_ascii=False,indent=2))
# A full-length silent track is distinct from generating narration.
with wave.open(str(R/'project'/'VOICEOVER.wav'),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(48000);w.writeframes(b'\0'*(58*48000*4))
