# ONE NEWS — cinematic reconstruction, 72 seconds

All server rooms, computers, circuit boards, global networks and asset-vault images are original three-dimensional illustrative environments rendered with Blender. They are NOT recordings of Binance premises, the actual attack, the perpetrators, actual asset routes or a market data feed. The frame label states this. No invented attack technique or geographic attribution is shown.

Editorial basis: six facts provided by the user as a verified editorial brief. The linked articles were not independently read. Approximately $6.3bn stolen, approximately 20-minute principal theft window, approximately $3bn frozen, and approximately 90% coverage as of 31 October 2026 are distinct claims. Frozen does not mean returned; coverage is a Binance statement, not an independently audited customer repayment figure. TraderTraitor attribution is explicitly an analyst assessment, not a final finding. No unverified 'largest ever' ranking is asserted.

## Deliverables
- ONE-NEWS-cinematic.mp4: vertical H.264, 1080x1920, 30 fps, 72 seconds. Default audio stream MUSIC; second stream VOICEOVER is digital silence for the full duration starting at zero. These streams are not mixed.
- ONE-NEWS-cinematic-clean.mp4: identical video, no audio stream.
- MUSIC.wav: original instrumental score, 48 kHz stereo PCM, no voice, no external samples.
- VOICEOVER.wav: 72 seconds of digital silence, 48 kHz stereo PCM, start 00:00.
- captions.srt: all on-screen text and timings, including the persistent illustration label. Captions are also burned into both MP4s; do not enable SRT on top unless replacing them in a new export.
- EDIT.mlt: Shotcut/MLT timeline with separate VIDEO, MUSIC and VOICEOVER tracks, all starting at frame zero. Keep alongside the MP4 and WAV files. There is no recorded speech on VOICEOVER: replace this silent clip with your recording.

## CapCut
MP4 audio streams are playback streams, not editable CapCut timeline tracks, and CapCut may import only the default audio. For reliable editing, import the clean MP4, MUSIC.wav and VOICEOVER.wav separately; place all at 00:00. Name the audio tracks MUSIC and VOICEOVER. Replace the silent VOICEOVER clip with your recording, leaving MUSIC independent. No native CapCut project format compatibility is claimed. EDIT.mlt is for Shotcut, not a native CapCut project.

## Rebuild
Python 3, NumPy, Pillow, Blender 4.3 (Eevee renderer) and FFmpeg with libx264/libass are required. Run `XDG_CACHE_HOME=/tmp/onenews-cache blender -b -t 4 --python scene.py` to build and render the 24-shot 3D project. Paths resolve relative to the project folder; rebuilds create render/ and output/ alongside project/. Frames are rendered at 6 fps, then motion-interpolated with scene-cut detection to 30 fps. Source imagery is 540x960 and upscaled to the requested 1080x1920; this is not a native 1080p source render. The .blend contains original geometry and animated cameras for higher-resolution rerendering. Run `python3 finish.py` to generate the score, subtitles, timeline and final exports.

Original logo_top_right.png and logo_bottom_left.png remain unavailable. No imitation branding or fabricated final logo is used. The files are an unbranded review cut pending those originals.
