from pathlib import Path
import subprocess,json,wave,xml.etree.ElementTree as E,hashlib
import numpy as np
from PIL import ImageFont
from finish import CAPS,wrap
O=Path(__file__).resolve().parent.parent/'output'
reports={}
for name in ['ONE-NEWS-cinematic.mp4','ONE-NEWS-cinematic-clean.mp4']:
 p=O/name
 j=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]))
 v=next(s for s in j['streams'] if s['codec_type']=='video')
 assert (v['width'],v['height'],v['codec_name'],v['r_frame_rate'],int(v['nb_frames']))==(1080,1920,'h264','30/1',2160),v
 assert abs(float(j['format']['duration'])-72)<.04
 audio=[s for s in j['streams'] if s['codec_type']=='audio']
 if 'clean' in name:assert not audio
 else:
  assert len(audio)==2
  assert [s['tags']['handler_name'] for s in audio]==['MUSIC','VOICEOVER']
  assert audio[0]['disposition']['default']==1 and audio[1]['disposition']['default']==0
  assert all(abs(float(s['start_time']))<.001 and abs(float(s['duration'])-72)<.04 for s in audio)
  raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-map','0:a:1','-f','s16le','-acodec','pcm_s16le','-'])
  assert np.max(np.abs(np.frombuffer(raw,dtype='<i2').astype(np.int32)))==0
 subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(p),'-map','0','-f','null','-'],check=True)
 reports[name]={'duration':j['format']['duration'],'video':{k:v[k] for k in ['width','height','codec_name','r_frame_rate','nb_frames']},'audio_tracks':[s['tags']['handler_name'] for s in audio],'full_decode':'passed','sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
for name in ['MUSIC.wav','VOICEOVER.wav']:
 with wave.open(str(O/name)) as w:
  assert w.getnframes()==72*48000 and w.getframerate()==48000 and w.getnchannels()==2
  if 'VOICEOVER' in name:assert not any(w.readframes(w.getnframes()))
xml=E.parse(O/'EDIT.mlt')
assert [p.find("property[@name='shotcut:name']").text for p in xml.findall('playlist')]==['VIDEO','MUSIC','VOICEOVER']
for p in xml.findall('chain'):assert (O/p.find("property[@name='resource']").text).is_file()
typography=[]
for a,b,title,sub in CAPS:
 for text,size in [(title,76 if a<3 else 62),(sub,32)]:
  rendered=wrap(text,size,820 if size>32 else 800)
  font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',size)
  widths=[font.getlength(line) for line in rendered.splitlines()]
  assert max(widths)<=820 and len(widths)<=3
  typography.append({'start':a,'end':b,'text':rendered,'font_px':size,'max_line_px':max(widths)})
assert CAPS[0][0]==0 and CAPS[-1][1]==72 and all(a[1]==b[0] for a,b in zip(CAPS,CAPS[1:]))
(O/'typography-check.json').write_text(json.dumps(typography,ensure_ascii=False,indent=2))
reports['limitations']=['Original brand PNGs not supplied; no imitation logo used.','All visuals are illustrative 3D; source articles were not independently accessed.','Source frames 540x960 at 6 fps; output upscaled and motion-interpolated to 1080x1920 at 30 fps.','EDIT.mlt is Shotcut format; CapCut workflow uses separate MP4 and WAV files.']
(O/'QA.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2))
print('PASS: both MP4s fully decode; 1080x1920, H.264, 30fps, 2160 frames, 72 seconds; MUSIC and silent VOICEOVER start at zero; clean cut has no audio; project paths resolve.')
