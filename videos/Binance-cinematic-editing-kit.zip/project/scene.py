import bpy, math, random
from mathutils import Vector
from pathlib import Path
R=Path(__file__).resolve().parent.parent; random.seed(63)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.render.engine='BLENDER_EEVEE_NEXT';s.eevee.taa_render_samples=4
s.render.threads_mode='FIXED';s.render.threads=4
s.render.resolution_x=540;s.render.resolution_y=960;s.render.resolution_percentage=100
s.render.fps=6;s.frame_start=1;s.frame_end=432
s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.005,.008,.015,1);s.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.12
s.view_settings.view_transform='AgX'
def mat(name,c,metal=0,em=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*c,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=.32
 if em:p.inputs['Emission Color'].default_value=(*c,1);p.inputs['Emission Strength'].default_value=em
 return m
metal=mat('Graphite steel',(.045,.057,.075),.8);black=mat('Screen',(.008,.014,.024),.2);silver=mat('Brushed aluminium',(.3,.35,.41),.85)
cyan=mat('Cold light',(.02,.45,.8),0,5);red=mat('Alarm light',(.8,.012,.025),0,5);gold=mat('Asset light',(.9,.4,.03),.6,1)
def box(name,loc,scale,m):
 x,y,z=[v/2 for v in scale];mesh=bpy.data.meshes.new(name)
 mesh.from_pydata([(-x,-y,-z),(x,-y,-z),(x,y,-z),(-x,y,-z),(-x,-y,z),(x,-y,z),(x,y,z),(-x,y,z)],[],[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)])
 mesh.update();o=bpy.data.objects.new(name,mesh);s.collection.objects.link(o);o.location=loc;o.data.materials.append(m)
 if min(scale)>.08:
  b=o.modifiers.new('Machined edges','BEVEL');b.width=.02;b.segments=2
 return o
def line(name,pts,m,r=.012):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.bevel_depth=r;c.bevel_resolution=1;p=c.splines.new('POLY');p.points.add(len(pts)-1)
 for a,b in zip(p.points,pts):a.co=(*b,1)
 o=bpy.data.objects.new(name,c);s.collection.objects.link(o);o.data.materials.append(m);return o
def light(loc,c,power,size=4):
 d=bpy.data.lights.new('Practical light','AREA');d.energy=power;d.color=c;d.shape='DISK';d.size=size;o=bpy.data.objects.new('Practical light',d);s.collection.objects.link(o);o.location=loc
def sphere(name,loc,r,m):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,radius=r,location=loc);o=bpy.context.object;o.name=name;o.data.materials.append(m);bpy.ops.object.shade_smooth();return o
# SET A: dimensional server aisle. No claim that this is Binance infrastructure.
box('Reflective floor',(0,0,-.12),(14,30,.2),metal)
box('Server ceiling',(0,0,4.6),(14,30,.15),black)
box('Far wall',(0,12,2),(14,.2,5),black)
for x in [-2.4,2.4]:
 for y in range(-10,12,2):
  box('Rack enclosure',(x,y,1.7),(1.1,1.55,3.4),metal)
  face=x+(.57 if x<0 else -.57)
  for z in range(12):
   box('Server blade',(face,y,.25+z*.25),(.035,1.4,.19),black)
   for k in range(4):box('Vent',(face+(.025 if x<0 else -.025),y-.52+k*.25,.25+z*.25),(.025,.16,.018),silver)
   box('Status indicator',(face+(.04 if x<0 else -.04),y+.55,.25+z*.25),(.035,.07,.025),cyan if z%5 else red)
 for y in range(-10,12,3):box('Overhead strip',(x*.6,y,4.2),(.06,2,.04),cyan)
light((0,-3,3.8),(.08,.4,1),900);light((0,8,3),(.8,.02,.03),1300)
# SET B: workstation, offset 40 m.
box('Desk',(40,0,.8),(5,2,.15),metal)
for x in [38.4,40,41.6]:
 o=box('Monitor',(x,.45,1.65),(1.45,.1,.9),metal)
 box('Monitor glass',(x,.38,1.65),(1.35,.02,.8),black)
 box('Stand',(x,.5,1.05),(.1,.1,.5),silver)
 for k in range(11):
  width=random.uniform(.2,1.1);box('Unlabelled diagnostic line',(x-.6+width/2,.36,1.32+k*.057),(width,.012,.012),cyan if k%3 else red)
box('Keyboard',(40,-.4,.92),(1.6,.5,.08),black)
for a in range(16):
 for b in range(4):box('Key',(39.28+a*.095,-.58+b*.1,.98),(.075,.075,.025),silver)
light((40,-2,3),(.05,.35,1),650);light((43,2,2),(1,.025,.04),500)
# SET C: luminous global network, schematic and no actual transaction routes.
center=Vector((80,0,2));sphere('Schematic globe',center,1.65,black)
for lat in range(-60,90,30):
 r=1.67*math.cos(math.radians(lat));z=2+1.67*math.sin(math.radians(lat));line('Latitude',[(80+r*math.cos(a),r*math.sin(a),z) for a in [i*math.tau/96 for i in range(97)]],cyan,.006)
for lon in range(0,180,30):
 a=math.radians(lon);line('Meridian',[(80+1.67*math.cos(t)*math.cos(a),1.67*math.cos(t)*math.sin(a),2+1.67*math.sin(t)) for t in [i*math.tau/96 for i in range(97)]],cyan,.006)
for k in range(12):
 a=random.random()*math.tau;b=a+random.uniform(.5,2);pts=[]
 for i in range(40):
  u=i/39;ang=a+(b-a)*u;r=1.7+.7*math.sin(math.pi*u);pts.append((80+r*math.cos(ang),r*math.sin(ang),2+.7*math.sin(ang*2+k)))
 line('Illustrative route',pts,red if k%3==0 else gold,.012)
light((80,-4,4),(.04,.3,1),1100)
# SET D: electronic vault / asset blocks.
box('Vault ground',(120,0,-.1),(10,10,.2),metal)
for x in range(-3,4):
 for y in range(-3,4):
  z=.2+((x*x+y*7)%5)*.15;box('Digital asset block',(120+x*.65,y*.65,z),(.5,.5,z*2),metal)
  box('Asset illumination',(120+x*.65,y*.65,z*2+.01),(.4,.4,.02),gold if x<0 else cyan)
for r in [2.8,3.2]:line('Containment ring',[(120+r*math.cos(a),r*math.sin(a),.08) for a in [i*math.tau/96 for i in range(97)]],cyan,.025)
light((120,-2,5),(.15,.35,1),1500);light((124,1,2),(1,.15,.02),800)
# SET E: chip with animated packets, detailed physical traces.
box('Circuit substrate',(160,0,0),(8,8,.15),black);box('Processor',(160,0,.35),(2.4,2.4,.6),metal)
box('Processor lid',(160,0,.68),(1.8,1.8,.06),silver)
for k in range(16):
 y=-1.05+k*.14
 for side in [-1,1]:
  line('Circuit trace',[(160+side*1.2,y,.2),(160+side*(1.6+k*.07),y,.2),(160+side*(1.6+k*.07),y+side*1.8,.2),(160+side*3.8,y+side*1.8,.2)],cyan if k%3 else red,.012)
light((160,-2,4),(.05,.4,1),1300);light((163,2,3),(1,.03,.03),800)
# Moving illustrative packets. Their paths are fictional graphic motifs, not attack evidence.
for k in range(9):
 o=sphere('Illustrative moving packet',(80,0,2),.045,gold)
 for frame in range(1,433,3):
  a=frame*.065+k*.7;r=1.85+.2*math.sin(a*2)
  o.location=(80+r*math.cos(a),r*math.sin(a),2+.8*math.sin(a+k));o.keyframe_insert('location',frame=frame)
 for fc in o.animation_data.action.fcurves:
  for point in fc.keyframe_points:point.interpolation='LINEAR'
# 24 continuous camera moves with hard editorial cuts every three seconds.
shots=[
 ('chip',(160,-3,3.5),(160,-2.2,2.2),(160,0,.4)),
 ('aisle',(0,-8,1.8),(.35,-5,1.65),(0,4,1.7)),
 ('aisle',(0,-5,1.7),(0,-1,1.7),(0,8,1.6)),
 ('monitor',(38,-2.5,2.2),(39.7,-1.8,1.7),(40,.4,1.6)),
 ('rack',(-.8,-1,1.5),(-.7,1.5,2.1),(-1.85,2,1.5)),
 ('chip',(158,-2,2.5),(161,-2,3.2),(160,0,.4)),
 ('globe',(80,-6,3),(82,-5,3.2),(80,0,2)),
 ('chip',(165,5,8),(162,6,8),(160,0,.4)),
 ('globe',(83,-4,3),(81,-4.2,1.8),(80,0,2)),
 ('aisle',(0,1,1.5),(0,4,2.1),(0,10,1.5)),
 ('monitor',(42,-2,1.6),(40.5,-1.7,1.8),(40,.4,1.6)),
 ('globe',(79,-4,2),(77,-4,3),(80,0,2)),
 ('chip',(160,-1.8,1.7),(160,-1.3,1.1),(160,0,.5)),
 ('rack',(.8,3,1.5),(.7,5,2.3),(1.85,4,1.7)),
 ('vault',(120,-5,4),(122,-4,3),(120,0,.4)),
 ('vault',(118,-2,2),(119,-1,2.5),(120,0,.4)),
 ('globe',(82,-5,2),(80,-5,3.4),(80,0,2)),
 ('vault',(122,0,3),(121,-2,3.7),(120,0,.4)),
 ('monitor',(40,-3,2.6),(40,-2.2,1.7),(40,.4,1.5)),
 ('aisle',(0,-4,1.3),(0,-1,2.2),(0,9,1.7)),
 ('vault',(120,-3,4),(118,-3,4),(120,0,.2)),
 ('globe',(80,-4,2),(82,-6,3),(80,0,2)),
 ('aisle',(0,5,1.7),(0,1,2.2),(0,10,1.7)),
 ('globe',(81,-5,3),(80,-8,3),(80,0,2))]
for i,(name,a,b,target) in enumerate(shots):
 d=bpy.data.cameras.new(name);d.lens=28 if name=='aisle' else 38;d.clip_end=40;o=bpy.data.objects.new('CAM_'+str(i),d);s.collection.objects.link(o)
 start=i*18+1;end=start+17
 for frame,loc in [(start,a),(end,b)]:
  o.location=loc;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler();o.keyframe_insert('location',frame=frame);o.keyframe_insert('rotation_euler',frame=frame)
 for fc in o.animation_data.action.fcurves:
  for k in fc.keyframe_points:k.interpolation='LINEAR'
 if i==7:
  aim=bpy.data.objects.new('Chip tracking target',None);s.collection.objects.link(aim);aim.location=target
  track=o.constraints.new('TRACK_TO');track.target=aim;track.track_axis='TRACK_NEGATIVE_Z';track.up_axis='UP_Y'
 marker=s.timeline_markers.new(name,frame=start);marker.camera=o
s.camera=bpy.data.objects['CAM_0']
s.render.image_settings.file_format='PNG';s.render.filepath=str(R/'render'/'frame-')
bpy.ops.wm.save_as_mainfile(filepath=str(R/'project'/'cinematic.blend'))
bpy.ops.render.render(animation=True)
