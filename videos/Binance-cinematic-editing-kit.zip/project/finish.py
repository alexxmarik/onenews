from pathlib import Path
import sys,json,math,subprocess,wave,zipfile
import numpy as np
from PIL import ImageFont
R=Path(__file__).resolve().parent.parent;O=R/'output';O.mkdir(exist_ok=True)
T=72;SR=48000
CAPS=[
(0,1.5,'$6 300 000 000','ПРИБЛИЗНО ВИКРАДЕНО • ЗА ДАНИМИ BINANCE'),
(1.5,3,'≈ 20 ХВИЛИН','МАСШТАБНЕ КРИПТОПОГРАБУВАННЯ'),
(3,9,'BINANCE ПІД УДАРОМ','Викрадено криптоактиви приблизно на $6,3 млрд'),
(9,15,'БЛИЗЬКО 20 ХВИЛИН','Основна частина викрадення • Reuters / блокчейн-аналіз'),
(15,21,'СЛІД ЗАЛИШИВСЯ В БЛОКЧЕЙНІ','За редакційною довідкою: транзакції аналізували'),
(21,27,'МАРШРУТИ НЕ ВІДТВОРЮЄМО','Рух коштів тут — умовна візуалізація'),
(27,33,'ХТО ЗА АТАКОЮ?','Аналітичні компанії вказують на можливий зв’язок'),
(33,39,'TraderTraitor','Північнокорейське угруповання • оцінка аналітиків'),
(39,42,'ЦЕ НЕ ОСТАТОЧНИЙ ВИСНОВОК','Атрибуцію не подаємо як доведений факт'),
(42,48,'≈ $3 МЛРД ЗАМОРОЖЕНО','За повідомленням Binance'),
(48,51,'ЗАМОРОЖЕНО ≠ ПОВЕРНУТО','Це різні стани активів'),
(51,57,'≈ 90% ПОКРИТТЯ','Заява Binance станом на 31 жовтня 2026 року'),
(57,63,'ВЛАСНІ КОШТИ. РЕЗЕРВИ. ФОНДИ.','Джерела покриття — за заявою Binance'),
(63,66,'КОРИСТУВАЧІ НЕ МАЮТЬ ВТРАТИТИ','Таку позицію заявила Binance'),
(66,72,'ЧИ БЕЗПЕЧНІ ЦИФРОВІ ГРОШІ?','За редакційною довідкою замовника'),
]
def time(t,ass=False):
 h=int(t//3600);m=int(t//60)%60;s=int(t)%60;ms=round((t-int(t))*1000)
 return f'{h}:{m:02}:{s:02}.{ms//10:02}' if ass else f'{h:02}:{m:02}:{s:02},{ms:03}'
def wrap(text,size,width):
 f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',size);lines=['']
 for word in text.split():
  q=(lines[-1]+' '+word).strip()
  if f.getlength(q)>width and lines[-1]:lines.append(word)
  else:lines[-1]=q
 return '\n'.join(lines)
def captions():
 head='''[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Main,DejaVu Sans,64,&H00FFFFFF,&H00FFFFFF,&H00101010,&H80000000,-1,0,0,0,100,100,0,0,1,3,2,5,0,0,0,1
Style: Small,DejaVu Sans,30,&H00E1E8EC,&H00FFFFFF,&H00101010,&H80000000,0,0,0,0,100,100,0,0,1,2,1,5,0,0,0,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
 events=[];srt=[]
 def event(a,b,text,style,x,y,sz,fade=True):
  text=text.replace('\n',r'\N');tags=rf'\pos({x},{y})\fs{sz}'+(r'\fad(100,120)' if fade else '')
  events.append(f'Dialogue: 0,{time(a,True)},{time(b,True)},{style},,0,0,0,,{{{tags}}}{text}')
 for i,(a,b,title,sub) in enumerate(CAPS,1):
  sz=76 if i<=2 else 62;title=wrap(title,sz,820);sub=wrap(sub,32,800)
  event(a,b,title,'Main',510,1050,sz);event(a,b,sub,'Small',510,1280,32)
  srt.append(f'{i}\n{time(a)} --> {time(b)}\n'+title+'\n'+sub+'\n3D-ІЛЮСТРАЦІЯ • НЕ ЗАПИС АТАКИ\n')
 event(0,T,'3D-ІЛЮСТРАЦІЯ • НЕ ЗАПИС АТАКИ','Small',510,245,26,False)
 (O/'captions.ass').write_text(head+'\n'.join(events)+'\n');(O/'captions.srt').write_text('\n'.join(srt))
 (R/'project'/'storyboard.json').write_text(json.dumps(CAPS,ensure_ascii=False,indent=2))
def audio():
 t=np.arange(SR*T)/SR;sig=np.zeros_like(t);rng=np.random.default_rng(630)
 # Original instrumental score: sub-bass pulse, minor arpeggio, risers and restrained impacts.
 for start in np.arange(0,66,.5):
  intensity=.45+.55*min(start/48,1);idx=int(start*SR);n=int(.45*SR);x=np.arange(n)/SR
  kick=.16*intensity*np.sin(2*np.pi*(42*x+1.8*(1-np.exp(-x*30))))*np.exp(-x*12)
  sig[idx:idx+n]+=kick
 for j,start in enumerate(np.arange(3,66,.25)):
  idx=int(start*SR);n=int(.23*SR);x=np.arange(n)/SR;freq=[110,130.81,164.81,220,164.81,130.81,146.83,196][j%8]
  env=np.minimum(x/.008,1)*np.exp(-x*18);gain=.025+.02*min(start/48,1)
  sig[idx:idx+n]+=gain*(np.sin(2*np.pi*freq*x)+.2*np.sin(2*np.pi*freq*3*x))*env
 for f in [55,65.405,82.405]:sig+=.018*np.sin(2*np.pi*f*t+.12*np.sin(t*.4))*np.minimum(t/6,1)
 for start in [0,3,15,27,39,42,51,63,66]:
  idx=int(start*SR);n=int(2*SR);x=np.arange(n)/SR;impact=.09*np.sin(2*np.pi*(36*x+2*(1-np.exp(-x*12))))*np.exp(-x*3)
  noise=rng.normal(0,.02,n)*np.exp(-x*6);sig[idx:idx+n]+=impact+noise
 for start in [24,36,48,60]:
  idx=int(start*SR);n=int(3*SR);x=np.arange(n)/SR;sig[idx:idx+n]+=.02*np.sin(2*np.pi*(130*x+90*x*x))*(x/3)**2
 sig*=np.minimum(t/.1,1)*np.minimum((T-t)/4,1);sig=np.tanh(sig*1.5)*.7
 stereo=np.column_stack([sig,np.roll(sig,280)*.95]);stereo[:280,1]=sig[:280]
 for name,data in [('MUSIC.wav',stereo),('VOICEOVER.wav',np.zeros((SR*T,2)))]:
  with wave.open(str(O/name),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes((data*32767).astype('<i2').tobytes())
def run(args):subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-stats_period','10','-stats','-y',*args],check=True)
def export():
 run(['-framerate','6','-i',str(R/'render/frame-%04d.png'),'-vf',f'minterpolate=fps=30:mi_mode=mci:mc_mode=obmc:me_mode=bilat:me=epzs:mb_size=16:search_param=8:vsbmc=0:scd=fdiff:scd_threshold=5,tpad=stop_mode=clone:stop=30,scale=1080:1920:flags=lanczos,hqdn3d=1.5:1.5:3:3,eq=contrast=1.05:saturation=0.85,rgbashift=rh=12:bh=-12:enable=between(t\\,0.2\\,0.33),drawbox=x=0:y=ih*0.3:w=iw:h=12:color=white@0.7:t=fill:enable=between(t\\,0.23\\,0.27),ass={O}/captions.ass,fade=t=in:st=0:d=0.18,fade=t=out:st=70.7:d=1.3','-t',str(T),'-c:v','libx264','-preset','fast','-crf','18','-threads','4','-pix_fmt','yuv420p','-an','-movflags','+faststart',str(O/'ONE-NEWS-cinematic-intermediate.mp4')])
 run(['-i',str(O/'ONE-NEWS-cinematic-intermediate.mp4'),'-vf','tpad=stop=30:stop_mode=clone,fade=t=out:st=71:d=1','-t',str(T),'-an','-c:v','libx264','-preset','fast','-crf','18','-threads','4','-pix_fmt','yuv420p','-movflags','+faststart',str(O/'ONE-NEWS-cinematic-clean.mp4')])
 run(['-i',str(O/'ONE-NEWS-cinematic-clean.mp4'),'-i',str(O/'MUSIC.wav'),'-i',str(O/'VOICEOVER.wav'),'-map','0:v','-map','1:a','-map','2:a','-c:v','copy','-c:a','aac','-b:a','192k','-metadata:s:a:0','title=MUSIC','-metadata:s:a:0','handler_name=MUSIC','-metadata:s:a:1','title=VOICEOVER','-metadata:s:a:1','handler_name=VOICEOVER','-disposition:a:0','default','-disposition:a:1','0','-t',str(T),'-movflags','+faststart',str(O/'ONE-NEWS-cinematic.mp4')])
def project():
 import xml.etree.ElementTree as E
 m=E.Element('mlt',producer='tractor',version='7.24.0');E.SubElement(m,'profile',frame_rate_num='30',frame_rate_den='1',width='1080',height='1920',progressive='1',sample_aspect_num='1',sample_aspect_den='1',display_aspect_num='9',display_aspect_den='16',colorspace='709')
 for pid,file in [('video','ONE-NEWS-cinematic-clean.mp4'),('music','MUSIC.wav'),('voice','VOICEOVER.wav')]:
  p=E.SubElement(m,'chain',id=pid,**{'in':'0','out':'2159'});E.SubElement(p,'property',name='resource').text=file;E.SubElement(p,'property',name='mlt_service').text='avformat'
 for pid,name in [('video','VIDEO'),('music','MUSIC'),('voice','VOICEOVER')]:
  p=E.SubElement(m,'playlist',id=pid+'_track');E.SubElement(p,'property',name='shotcut:name').text=name;E.SubElement(p,'property',name='shotcut:trackHeight').text='80';E.SubElement(p,'entry',producer=pid,**{'in':'0','out':'2159'})
 tr=E.SubElement(m,'tractor',id='tractor',shotcut='1',**{'in':'0','out':'2159'});E.SubElement(tr,'property',name='shotcut:name').text='Timeline'
 for name in ['voice','music','video']:E.SubElement(tr,'track',producer=name+'_track',hide='video' if name!='video' else 'audio')
 for b in [1,2]:
  trans=E.SubElement(tr,'transition',**{'in':'0','out':'2159'});
  for k,v in [('mlt_service','mix'),('a_track','0'),('b_track',str(b)),('always_active','1'),('sum','1')]:E.SubElement(trans,'property',name=k).text=v
 E.ElementTree(m).write(O/'EDIT.mlt',encoding='utf-8',xml_declaration=True)
if __name__=='__main__':
 captions();audio();project()
 if '--prepare' not in sys.argv:export()
