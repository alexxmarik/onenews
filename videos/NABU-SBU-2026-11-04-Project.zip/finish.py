from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import subprocess,json
R=Path(__file__).parent;P=R/'project';O=R/'output';O.mkdir(exist_ok=True);F='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
cues=[
(0,5,'ПОГРОЗИ ЗБРОЄЮ\nПІД ЧАС ОБШУКІВ?','Що повідомило НАБУ',58),
(5,12,'НАБУ ЗАЯВИЛО\nПРО ПЕРЕШКОДЖАННЯ','4 листопада 2026 року',52),
(12,20,'БЮРО ПОВІДОМИЛО\nПРО ПОГРОЗИ ЗБРОЄЮ','Обшук — за ухвалою судді ВАКС',49),
(20,29,'НАБУ: ПРИБУЛИ\nСПЕЦПРИЗНАЧЕНЦІ СБУ','Це твердження бюро',48),
(29,39,'ДЖЕРЕЛА МЕДІА\nНАЗИВАЮТЬ СЕРГІЯ ДУКУ','У первинній заяві НАБУ імені не було',46),
(39,49,'КРАВЧЕНКО НАЗВАВ ЦЕ\n«ПОЛІТИЧНОЮ ПОМСТОЮ»','Його публічна оцінка дій НАБУ та САП',44),
(49,58,'НАБУ ОБІЦЯЄ\nОПРИЛЮДНИТИ ПОДРОБИЦІ','Слідкуємо за розвитком подій',46)]
def tm(s):
 h=int(s//3600);m=int(s//60)%60;sec=s%60;return f'{h}:{m:02}:{sec:05.2f}'
header='''[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Main,DejaVu Sans,50,&H00FFFFFF,&H000000FF,&H000B1425,&H00000000,-1,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1
Style: Sub,DejaVu Sans,30,&H00D9E2EF,&H000000FF,&H000B1425,&H00000000,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
lines=[]
for a,b,main,sub,size in cues:
 for l in main.splitlines():assert ImageFont.truetype(F,size).getlength(l)<=806,(l,size)
 assert ImageFont.truetype(F,30).getlength(sub)<=805,sub
 txt=main.replace('\n',r'\N')
 source='ДЖЕРЕЛО: НАБУ • ЗАЯВА 4 ЛИСТОПАДА' if a<29 or a>=49 else ('ДЖЕРЕЛА: УКРАЇНСЬКА ПРАВДА / СУСПІЛЬНЕ' if a<39 else 'ДЖЕРЕЛО: ПУБЛІКАЦІЯ РУСЛАНА КРАВЧЕНКА')
 lines.append(f'Dialogue: 1,{tm(a)},{tm(b)},Sub,,0,0,0,,{{\\pos(90,1400)\\fs21\\c&HD1B7A0&}}{source}')
 lines.append(f'Dialogue: 1,{tm(a)},{tm(b)},Main,,0,0,0,,{{\\move(90,1216,90,1195,0,240)\\fad(150,100)\\fs{size}}}{txt}')
 lines.append(f'Dialogue: 1,{tm(a)},{tm(b)},Sub,,0,0,0,,{{\\pos(90,1350)\\fad(220,100)}}{sub}')
(P/'headlines.ass').write_text(header+'\n'.join(lines)+'\n')
im=Image.new('RGBA',(1080,1920));d=ImageDraw.Draw(im)
d.rounded_rectangle((64,234,217,293),radius=5,fill=(199,31,54,255));d.text((82,242),'NEWS',font=ImageFont.truetype(F,35),fill='white')
d.text((240,247),'НАБУ / СБУ',font=ImageFont.truetype(F,28),fill='white')
d.text((704,249),'04.11.2026',font=ImageFont.truetype(F,29),fill='white')
d.rounded_rectangle((64,1160,944,1430),radius=12,fill=(5,16,36,247));d.rectangle((64,1160,73,1430),fill=(212,37,62))
# Source is set separately for each headline in ASS.
im.save(P/'news-layout.png')
ticker='НАБУ: ЗАЯВА ПРО ПЕРЕШКОДЖАННЯ ОБШУКУ   •   УХВАЛА СУДДІ ВАКС   •   ІМ’Я ПОСАДОВЦЯ — ЗА ДЖЕРЕЛАМИ МЕДІА   •   '
(P/'ticker.txt').write_text(ticker)
# Build intermediate transitions in one filter graph with an explicit constant timebase.
shots=json.loads((P/'timeline.json').read_text())['shots'];args=['ffmpeg','-v','warning','-y','-filter_complex_threads','1']
for i in range(len(shots)):args+=['-threads','1','-i',str(R/'clips'/f'{i:02d}.mp4')]
args+=['-loop','1','-i',str(P/'news-layout.png'),'-i',str(P/'VOICEOVER.wav')]
g=[]
for i in range(len(shots)):g.append(f'[{i}:v]setpts=PTS-STARTPTS,fps=30,settb=1/30,format=yuv420p[v{i}]')
prev='v0';offset=0
for i in range(1,len(shots)):
 offset+=shots[i-1]['timeline_duration'];n=f'x{i}';g.append(f'[{prev}][v{i}]xfade=transition=fade:duration=0.133333333:offset={offset},fps=30,settb=1/30[{n}]');prev=n
g.append(f'[{prev}][{len(shots)}:v]overlay=0:0,ass={P}/headlines.ass[news]')
g.append(f"color=c=0xB41630:s=880x58:r=30:d=58,drawtext=fontfile={F}:textfile={P}/ticker.txt:fontsize=27:fontcolor=white:x=w-mod(t*95\\,text_w+w):y=(h-text_h)/2[ticker]")
g.append('[news][ticker]overlay=64:1460,format=yuv420p[out]')
(P/'filter.txt').write_text(';\n'.join(g))
args+=['-filter_complex_script',str(P/'filter.txt'),'-map','[out]','-map',f'{len(shots)+1}:a:0','-frames:v','1740','-t','58','-c:v','libx264','-profile:v','baseline','-level:v','4.0','-preset','fast','-crf','23','-maxrate','6500k','-bufsize','13000k','-threads','3','-pix_fmt','yuv420p','-c:a','aac','-b:a','96k','-ar','48000','-metadata:s:a:0','title=VOICEOVER','-metadata:s:a:0','handler_name=VOICEOVER','-metadata','title=НАБУ та СБУ — 04.11.2026','-movflags','+faststart',str(O/'NABU-SBU-2026-11-04-Reels.mp4')]
(P/'render-command.json').write_text(json.dumps(args,ensure_ascii=False,indent=2))
with (P/'render.log').open('w') as log:subprocess.run(args,check=True,stdout=log,stderr=log)
print('RENDER COMPLETE',flush=True)
