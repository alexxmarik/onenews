from pathlib import Path
import json,math
from PIL import Image,ImageDraw,ImageFont,ImageFilter
R=Path(__file__).parent;P=R/'project';P.mkdir(exist_ok=True)
# Coastlines only: no de-facto occupation lines are presented as national borders.
W,H=880,640
land=Image.new('L',(W,H));d=ImageDraw.Draw(land)
lon0,lon1=-130,90;lat0,lat1=8,76
def merc(lat):return math.log(math.tan(math.pi/4+math.radians(max(-85,min(85,lat)))/2))
xrange=math.radians(lon1-lon0);yrange=merc(lat1)-merc(lat0);scale=min((W-40)/xrange,(H-80)/yrange)
xoff=(W-scale*xrange)/2;yoff=(H-scale*yrange)/2
def xy(lon,lat):return xoff+math.radians(lon-lon0)*scale,yoff+(merc(lat1)-merc(lat))*scale
for f in json.loads((R/'world.geojson').read_text())['features']:
 g=f['geometry'];polys=[g['coordinates']] if g['type']=='Polygon' else g['coordinates']
 for poly in polys:
  coords=poly[0]
  # Avoid wrap-around artifacts at the antimeridian, outside this viewport.
  if max(x[0] for x in coords)-min(x[0] for x in coords)>180:continue
  pts=[xy(a,b) for a,b,*_ in coords];d.polygon(pts,fill=255)
canvas=Image.new('RGBA',(W,H),(5,17,36,246));color=Image.new('RGBA',(W,H),(38,65,91,255));canvas.alpha_composite(Image.composite(color,Image.new('RGBA',(W,H)),land))
edge=land.filter(ImageFilter.FIND_EDGES);coast=Image.new('RGBA',(W,H),(91,126,155,155));canvas.alpha_composite(Image.composite(coast,Image.new('RGBA',(W,H)),edge))
d=ImageDraw.Draw(canvas);font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
for lon in range(-120,100,30):
 x,_=xy(lon,0);d.line((x,45,x,H-35),fill=(78,101,128,50),width=1)
for lat in [20,40,60]:
 _,y=xy(0,lat);d.line((25,y,W-25,y),fill=(78,101,128,50),width=1)
pts={'США':(-77.0369,38.9072),'УКРАЇНА':(30.5234,50.4501),'РОСІЯ':(37.6173,55.7558),'АБУ-ДАБІ':(54.3773,24.4539)}
labels={'США':(-90,22),'УКРАЇНА':(-105,18),'РОСІЯ':(12,-45),'АБУ-ДАБІ':(-130,22)}
for k,(lon,lat) in pts.items():
 x,y=xy(lon,lat);c=(232,43,66,255) if k=='АБУ-ДАБІ' else (225,238,250,255)
 d.ellipse((x-7,y-7,x+7,y+7),fill=c)
 dx,dy=labels[k];d.text((x+dx,y+dy),k,font=ImageFont.truetype(font,30),fill='white',stroke_width=2,stroke_fill=(5,17,36))
 if k=='АБУ-ДАБІ':d.text((x+dx,y+dy+34),'ОАЕ',font=ImageFont.truetype(font,26),fill=(193,209,228))
d.text((26,20),'ТРИ КРАЇНИ • ОДИН ДИПЛОМАТИЧНИЙ ФОРМАТ',font=ImageFont.truetype(font,26),fill='white')
# Full geodata attribution is retained in the sources document.
canvas.save(P/'map.png')
(P/'map-coordinates.json').write_text(json.dumps({'projection':'Mercator, equal x/y metric scale','data_source':'Natural Earth, public domain','boundary_policy':'Only coastlines, no disputed or occupation boundaries','points_lon_lat':pts},ensure_ascii=False,indent=2))
