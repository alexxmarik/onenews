from pathlib import Path
import subprocess,json,xml.etree.ElementTree as E
R=Path(__file__).parent;P=R/'project';O=R/'output';v=O/'ABU-DHABI-2026-11-04-picture.mp4'
def run(cmd):subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
run(['ffmpeg','-v','error','-y','-i',str(v),'-i',str(P/'MUSIC.wav'),'-i',str(P/'VOICEOVER.wav'),'-map','0:v:0','-map','1:a:0','-map','2:a:0','-t','58','-c:v','copy','-filter:a:0','volume=-12dB','-c:a','aac','-b:a','128k','-metadata:s:a:0','title=MUSIC','-metadata:s:a:0','handler_name=MUSIC','-metadata:s:a:1','title=VOICEOVER','-metadata:s:a:1','handler_name=VOICEOVER','-disposition:a:0','default','-disposition:a:1','0','-metadata','title=Переговори в Абу-Дабі — 04.11.2026','-movflags','+faststart',str(O/'ABU-DHABI-2026-11-04-Reels.mp4')])
run(['ffmpeg','-v','error','-y','-i',str(v),'-i',str(P/'VOICEOVER.wav'),'-map','0:v:0','-map','1:a:0','-t','58','-c:v','copy','-c:a','aac','-b:a','96k','-metadata:s:a:0','handler_name=VOICEOVER','-metadata:s:a:0','title=VOICEOVER','-movflags','+faststart',str(O/'ABU-DHABI-2026-11-04-NoMusic.mp4')])
run(['ffmpeg','-v','error','-y','-i',str(P/'MUSIC.wav'),'-c:a','libmp3lame','-b:a','192k','-metadata','title=ONE NEWS — Diplomatic background, 58 seconds',str(O/'ABU-DHABI-MUSIC.mp3')])
# A standard Shotcut/MLT timeline also retains independently replaceable audio layers.
root=E.Element('mlt',{'producer':'tractor','version':'7.24.0'});E.SubElement(root,'profile',{'description':'Vertical 1080x1920 30fps','width':'1080','height':'1920','frame_rate_num':'30','frame_rate_den':'1','progressive':'1','sample_aspect_num':'1','sample_aspect_den':'1','display_aspect_num':'9','display_aspect_den':'16','colorspace':'709'})
for cid,res,label in [('v','../output/ABU-DHABI-2026-11-04-NoMusic.mp4','VIDEO'),('m','MUSIC.wav','MUSIC'),('a','VOICEOVER.wav','VOICEOVER')]:
 c=E.SubElement(root,'chain',{'id':cid,'out':'1739'});E.SubElement(c,'property',{'name':'resource'}).text=res;E.SubElement(c,'property',{'name':'mlt_service'}).text='avformat';E.SubElement(c,'property',{'name':'shotcut:producer'}).text='1'
 if cid=='v':E.SubElement(c,'property',{'name':'audio_index'}).text='-1'
 else:E.SubElement(c,'property',{'name':'video_index'}).text='-1'
 if cid=='m':
  f=E.SubElement(c,'filter');E.SubElement(f,'property',{'name':'mlt_service'}).text='volume';E.SubElement(f,'property',{'name':'level'}).text='0.25118864'
 p=E.SubElement(root,'playlist',{'id':cid+'p'});E.SubElement(p,'property',{'name':'shotcut:name'}).text=label
 if cid!='v':E.SubElement(p,'property',{'name':'shotcut:trackHeight'}).text='64';E.SubElement(p,'property',{'name':'shotcut:trackAudio'}).text='1'
 E.SubElement(p,'entry',{'producer':cid,'in':'0','out':'1739'})
t=E.SubElement(root,'tractor',{'id':'tractor','shotcut':'1','in':'0','out':'1739'});E.SubElement(t,'property',{'name':'shotcut:name'}).text='ABU DHABI — 04.11.2026'
for cid,hide in [('v','audio'),('m','video'),('a','video')]:E.SubElement(t,'track',{'producer':cid+'p','hide':hide})
for b in [1,2]:
 tr=E.SubElement(t,'transition',{'in':'0','out':'1739'});
 for name,val in [('mlt_service','mix'),('a_track','0'),('b_track',str(b)),('always_active','1'),('sum','1')]:E.SubElement(tr,'property',{'name':name}).text=val
E.ElementTree(root).write(P/'ABU-DHABI.mlt',encoding='utf-8',xml_declaration=True)
print('Both MP4s, separate music and timeline ready',flush=True)
