from pathlib import Path
import subprocess,json,hashlib,ast,re,concurrent.futures
R=Path(__file__).parent;P=R/'project';O=R/'output'
reports=[]
for name in ['ABU-DHABI-2026-11-04-Reels.mp4','ABU-DHABI-2026-11-04-NoMusic.mp4']:
 v=O/name
 report=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries','format=duration,size:stream=index,codec_name,profile,width,height,sample_aspect_ratio,r_frame_rate,start_time,duration,nb_read_frames:stream_tags=handler_name:stream_disposition','-of','json',str(v)]))
 assert report['streams'][0]['width']==1080 and report['streams'][0]['height']==1920
 assert report['streams'][0]['r_frame_rate']=='30/1' and report['streams'][0]['nb_read_frames']=='1740'
 assert report['format']['duration']=='58.000000'
 for s in report['streams']:assert s['start_time']=='0.000000' and s['duration']=='58.000000'
 report['file']=name;report['sha256']=hashlib.sha256(v.read_bytes()).hexdigest();reports.append(report)
 with (P/(name+'.validation.log')).open('w') as log:
  cmd=['ffmpeg','-hide_banner','-v','info','-xerror','-threads','2','-i',str(v),'-vf','blackdetect=d=0.08:pix_th=0.08']
  if 'NoMusic' in name:cmd+=['-af','astats=metadata=1:reset=0']
  cmd+=['-f','null','-'];subprocess.run(cmd,stdout=log,stderr=log,check=True)
 text=(P/(name+'.validation.log')).read_text();assert 'black_start' not in text
 if 'NoMusic' in name:assert 'Peak level dB: -inf' in text
 hashes=[]
 with v.open('rb') as f:
  pos=0;atoms=[]
  while pos<v.stat().st_size:
   f.seek(pos);h=f.read(8)
   if len(h)<8:break
   size=int.from_bytes(h[:4],'big');typ=h[4:8].decode('ascii',errors='replace')
   if size==1:size=int.from_bytes(f.read(8),'big')
   if size<=0:break
   atoms.append(typ);pos+=size
 assert atoms.index('moov')<atoms.index('mdat')
 print('Validated',name,report['format']['size'],flush=True)
(P/'validation.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2))
# Preserve exactly the screen captions as an editable SRT.
code=ast.parse((R/'render.py').read_text());cues=next(ast.literal_eval(n.value) for n in code.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='C' for t in n.targets))
def stamp(s):
 ms=round(s*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
srt='\n\n'.join(f'{i+1}\n{stamp(a)} --> {stamp(b)}\n{title}\n{sub}' for i,(a,b,title,sub,_) in enumerate(cues))+'\n';(O/'ABU-DHABI-HEADLINES.srt').write_text(srt)
# Log manual review of OCR detections: false matches are shapes on national flags/seals.
audit=json.loads((R/'audit'/'ocr-report.json').read_text())
review=dict(method='Every normalized source frame represented in a 30-frame OCR sheet. English/Russian Tesseract recognition; fixed source-space blur masks applied before all reframing; manual review of every shot and all flagged text.',source_frame_count=sum(s['frames'] for s in json.loads((P/'timeline.json').read_text())['shots']),ocr_sheet_count=len(audit),detected=[dict(file=x['file'],matches=x['suspect']) for x in audit if x['suspect']],manual_resolution='11-04 and 18-02: @e matches are false recognition of pictorial detail/US state emblems; no channel address or text exists. The real WHITE HOUSE outro detected in original clip 15 was removed and that interval was replaced and rechecked.',result='No third-party overlay, media-source label, URL, channel handle, QR code or foreign subtitle found in the selected cleaned footage. State flags and faces preserved.')
(P/'graphics-audit.json').write_text(json.dumps(review,ensure_ascii=False,indent=2));print('Validation and caption files complete',flush=True)
