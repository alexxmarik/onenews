ABU DHABI NEWS REELS • 04.11.2026

58 seconds, 1080x1920, 30 fps, H264 Constrained Baseline. Original footage audio is never included. All documentary footage is visibly labelled archive with its year. No footage represents the future meeting.

AUDIO: MUSIC.wav is separate. VOICEOVER.wav is digital silence, full length, starting at 00:00. Replace it with your own narration. The ready master has MUSIC and silent VOICEOVER as separate MP4 audio streams; editors may import only the default stream, so use the no-music version and separate MUSIC file for complete control. The project MLT has independent music/voice tracks.

No-music MP4 is completely silent. Import it into CapCut and add your own recording on a separate audio layer. You can add the provided instrumental music as another layer.

RENDER: python render.py (requires FFmpeg/libass, Python/Pillow). The clips folder contains normalized, cleaned, silent documentary intervals. timeline.json, mask coordinates and normalize filter scripts document every source interval. map.py and map-coordinates.json document the geography. sources file contains source/license links and required CC BY credit for the publication description.
