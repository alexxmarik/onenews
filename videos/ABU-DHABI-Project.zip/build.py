from pathlib import Path
import subprocess,json,concurrent.futures,wave
R=Path(__file__).parent
for d in ['project','clips','output','review']:(R/d).mkdir(exist_ok=True)
# Source interval, screen duration and static framing. Additional four frames support dissolves.
S=[
('zelensky-trump',36,1.2,None,'ВОЛОДИМИР ЗЕЛЕНСЬКИЙ • АРХІВ 2025'),
('oval-portrait',2,1.2,None,'ДОНАЛЬД ТРАМП • АРХІВ 2025'),
('putin',5,1.2,'crop=570:720:0:0','ВОЛОДИМИР ПУТІН • АРХІВ 2017'),
('abu-dhabi',4,1.4,'crop=1440:800:0:1010','АБУ-ДАБІ • АРХІВ 2025'),
('abu-dhabi',6,4,'crop=1440:800:0:1010','АБУ-ДАБІ • АРХІВ 2025'),
('witkoff',.3,3,None,'СТІВ ВІТКОФФ • АРХІВ 2025'),
('kushner',4.2,3,'crop=700:1080:600:0','ДЖАРЕД КУШНЕР • АРХІВ 2018'),
('witkoff',13.1,3,None,'БІЛИЙ ДІМ • АРХІВ 2025'),
('zelensky-trump',38,3.5,None,'ВОЛОДИМИР ЗЕЛЕНСЬКИЙ • АРХІВ 2025'),
('oval-portrait',30,3.5,None,'УКРАЇНА — США • АРХІВ 2025'),
('zelensky-trump',43,3.5,None,'УКРАЇНА — США • АРХІВ 2025'),
('oval-portrait',52,3.5,None,'УКРАЇНА — США • АРХІВ 2025'),
('putin',28,3,'crop=570:720:0:0','ВОЛОДИМИР ПУТІН • АРХІВ 2017'),
('medinsky',32,4,'crop=760:1080:620:0','ВОЛОДИМИР МЕДИНСЬКИЙ • АРХІВ 2022'),
('oval-portrait',100,3,None,'ДОНАЛЬД ТРАМП • АРХІВ 2025'),
('putin',62,3,'crop=570:720:0:0','ВОЛОДИМИР ПУТІН • АРХІВ 2017'),
('zelensky-trump',60,3,None,'ВОЛОДИМИР ЗЕЛЕНСЬКИЙ • АРХІВ 2025'),
('abu-dhabi',16,3,'crop=1440:800:0:1010','АБУ-ДАБІ • АРХІВ 2025'),
('oval-portrait',70,1.5,None,'УКРАЇНА — США • АРХІВ 2025'),
('oval-portrait',115,1.5,None,'ДОНАЛЬД ТРАМП • АРХІВ 2025'),
('putin',45,1.5,'crop=570:720:0:0','ВОЛОДИМИР ПУТІН • АРХІВ 2017'),
('abu-dhabi',20,2.5,'crop=1440:800:0:1010','АБУ-ДАБІ • АРХІВ 2025')]
assert sum(x[2] for x in S)==58
# Mask positions are in native source pixels, before crop, scale and background rendering.
MASKS={
 'putin':[(1150,0,130,100)],
 'kushner':[(140,845,1640,220)],
 'medinsky':[(350,770,850,310)],
 # The portrait official edit has a large branded matte. Blur its text/pattern bands,
 # then retain only the unobstructed moving camera image, not the editorial frame.
 'abu-dhabi':[(0,0,1440,1010),(0,1810,1440,750)],
 'zelensky-trump':[], 'oval-portrait':[], 'witkoff':[]}
def run(i):
 name,start,dur,crop,label=S[i];frames=round(dur*30)+(4 if i<len(S)-1 else 0)
 g=[];last='0:v'
 for j,(x,y,w,h) in enumerate(MASKS[name]):
  g += [f'[{last}]split=2[b{j}][p{j}]',f'[p{j}]crop={w}:{h}:{x}:{y},boxblur=luma_radius=22:luma_power=3:chroma_radius=11:chroma_power=3[c{j}]',f'[b{j}][c{j}]overlay={x}:{y}[m{j}]'];last=f'm{j}'
 prefix=f'[{last}]'+(crop+',' if crop else '')
 # Portrait archives occupy the frame; city establishing shots retain their full width.
 if name=='abu-dhabi':
  g += [prefix+'fps=30,setsar=1,split=2[b][f]','[b]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=28:2,eq=brightness=-.23:saturation=.8[bg]','[f]scale=1080:600,eq=saturation=.9:contrast=1.025[fg]','[bg][fg]overlay=0:510,format=yuv420p[out]']
 else:g += [prefix+'fps=30,setsar=1,scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,eq=saturation=.9:contrast=1.025,format=yuv420p[out]']
 script=';'.join(g);(R/'project'/f'normalize-{i:02d}.ffscript').write_text(script)
 cmd=['ffmpeg','-v','error','-y','-threads','1','-ss',str(start),'-i',str(R/'originals'/(name+'.webm')),'-filter_complex_threads','1','-filter_complex',script,'-map','[out]','-an','-frames:v',str(frames),'-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-threads','2',str(R/'clips'/f'{i:02d}.mp4')]
 result=subprocess.run(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
 if result.returncode:raise RuntimeError(result.stderr.decode()[-1800:])
 print('ready clip',i,frames,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:list(p.map(run,range(len(S))))
time=0;shots=[]
for i,(name,start,dur,crop,label) in enumerate(S):
 shots.append(dict(index=i,source=name,source_start=start,timeline_start=time,timeline_duration=dur,frames=round(dur*30)+(4 if i<len(S)-1 else 0),label=label,source_crop=crop,blur_regions=MASKS[name]));time+=dur
(R/'project'/'timeline.json').write_text(json.dumps(dict(duration=58,fps=30,size=[1080,1920],transition_frames=4,shots=shots),ensure_ascii=False,indent=2))
with wave.open(str(R/'project'/'VOICEOVER.wav'),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(48000);w.writeframes(b'\0'*(58*48000*4))
