from pathlib import Path
import json
R=Path(__file__).parent;P=R/'project';O=R/'output'
parts=[
('00:00–00:05','Новий раунд переговорів про мир — в Абу-Дабі.'),
('00:05–00:09','Дати — десяте й одинадцяте листопада.'),
('00:09–00:12','Їх анонсував спецпредставник США Стів Віткофф.'),
('00:12–00:18','Сполучені Штати планують бути посередником між Україною та Росією. Йдеться про зустріч команд.'),
('00:18–00:21.5','Зеленський назвав пріоритетом припинення ударів по енергетиці.'),
('00:21.5–00:25','Серед пріоритетів — безпека судноплавства й зерновий коридор.'),
('00:25–00:28.5','Також — частіші обміни військовополоненими.'),
('00:28.5–00:32','І підготовка зустрічі лідерів за участю Європи.'),
('00:32–00:39','За повідомленнями медіа з посиланням на Кремль, російську делегацію очолить Володимир Мединський.'),
('00:39–00:45','Умови завершення війни сторони бачать по-різному.'),
('00:45–00:51','Станом на четверте листопада цей раунд ще попереду. Погодженої мирної угоди не оголошено.'),
('00:51–00:58','Чи наблизить нова зустріч Україну до справедливого миру?')]
full='\n\n'.join(t for _,t in parts)
(O/'ABU-DHABI-VOICEOVER.txt').write_text('ДИКТОРСЬКИЙ ТЕКСТ • АКТУАЛЬНІСТЬ 04.11.2026\n58 секунд. Озвучування не генерувалося. Таймінг орієнтовний для вашого читання.\n\n'+full+'\n\nТЕКСТ ЗА ТАЙМІНГОМ\n\n'+'\n\n'.join(a+'\n'+b for a,b in parts)+'\n')
print('narration words',len(full.split()))
S=[
('Офіційний сайт Президента України','https://www.president.gov.ua/en/news/zayava-prezidenta-ukrayini-pid-chas-spilnogo-z-premyer-minis-107057','Прочитано. Заява 28.10.2026: підготовка тристороннього формату, очікування до 10 листопада, важливість позиції Європи. Ця старіша заява сама по собі не підтверджує дати 10–11 листопада.'),
('Офіційний канал Президента України','https://t.me/V_Zelenskiy_official/21634','Прочитано. Заява 03.11.2026: очікування формату Україна—США—Росія 10–11 листопада на рівні команд; прагнення майбутньої зустрічі лідерів і залучення Європи.'),
('Interfax-Україна','https://en.interfax.com.ua/news/general/1230204.html','Прочитано. Анонс Віткоффа, дати, Абу-Дабі, робочий рівень переговорів та посередництво США.'),
('hromadske','https://hromadske.ua/en/society/273690-us-to-mediate-ukraine-russia-talks-in-abu-dhabi-on-november-10-11-witkoff-says','Прочитано. Незалежне зіставлення анонсу Віткоффа й попередніх дипломатичних контактів. Склад майбутніх делегацій у його повідомленні не уточнений.'),
('The Kyiv Independent','https://kyivindependent.com/witkoff-reveals-location-date-for-new-trilateral-peace-deal-negotiations/','Прочитано. Дати й місце; з посиланням на речника Кремля — Мединський; розбіжності щодо завершення війни; технічні переговори й можливий майбутній саміт.'),
('РБК-Україна','https://newsukraine.rbc.ua/news/security-guarantees-and-more-zelenskyy-reveals-1793718284.html','Прочитано. Чотири пріоритети Зеленського: енергетика, судноплавство/зерно, обміни, підготовка зустрічі лідерів із Європою. Це позиція України, а не погоджений сторонами порядок денний. Повідомляє про заяву Пєскова щодо Мединського.'),
('Reuters — надане посилання','https://www.reuters.com/world/europe/us-hold-trilateral-talks-with-ukraine-russia-abu-dhabi-next-week-us-official-2026-11-02/','Недоступне: HTTP 401 Unauthorized. Зміст цієї статті не використано і не приписано Reuters.'),
('Першоджерело анонсу Віткоффа в X','https://x.com/SEPeaceMissions/status/2117393678083792909','URL встановлено за посиланнями hromadske і Kyiv Independent. Вебсторінка не віддала читабельний текст поста; його зміст зіставлено за Interfax, hromadske і Kyiv Independent, а не заявлено як самостійно прочитаний у X.')]
media=[]
for name in ['media-manifest.json','extra-manifest.json','portrait-manifest.json']:media+=json.loads((R/name).read_text())
used={s['source'] for s in json.loads((P/'timeline.json').read_text())['shots']};media=[m for m in media if m['id'] in used]
(P/'fact-sources.json').write_text(json.dumps([dict(name=a,url=b,status=c) for a,b,c in S],ensure_ascii=False,indent=2))
(P/'used-media.json').write_text(json.dumps(media,ensure_ascii=False,indent=2))
text='ДЖЕРЕЛА ІНФОРМАЦІЇ\nАКТУАЛЬНІСТЬ: 4 листопада 2026 року\n\n'+'\n\n'.join(a+'\n'+b+'\n'+c for a,b,c in S)
text+='\n\nВИКОРИСТАНІ ВІДЕОМАТЕРІАЛИ\nУсі кадри є архівними, а не записом майбутньої зустрічі. Оригінальний звук повністю видалено.\n\n'
for m in media:text+=f"{m['id']}: {m['title']}\nДата: {m.get('date')}\nАвтор: {m.get('artist')}\nЛіцензія: {m.get('license')}\nСторінка: {m['page']}\nПрямий відеофайл: {m['download']}\n\n"
text+='ВАЖЛИВІ УТОЧНЕННЯ\nКушнер показаний як архівний портрет; його участь у майбутньому раунді не стверджується. Кадри мечеті в Абу-Дабі ілюструють місто та офіційний візит 2025 року, а не точне місце майбутніх переговорів. Старі висловлювання Мединського не озвучуються і не подаються як нинішня заява. Звук відвідування, пресконференцій і промов не використано. Карта показує берегові лінії та географічні точки; окупаційні межі не подаються як державні кордони.\n\nГЕОДАНІ\nNatural Earth, public domain: https://www.naturalearthdata.com/about/terms-of-use/\nhttps://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_110m_admin_0_countries.geojson\n\nМУЗИКА\nОригінальна процедурна інструментальна композиція для цього проєкту, без сторонніх семплів, голосу, вокалу чи ефектів інциденту. Скрипт синтезу included у проєкті.\n\nАТРИБУЦІЯ ДЛЯ ПУБЛІКАЦІЇ (додайте до опису ролика)\n'
m=next(m for m in media if m['id']=='medinsky')
text+=f"Архівні кадри Мединського: {m['artist']}, «Вторая встреча — Заявление Мединского до начала переговоров — Прямой эфир», 02.03.2022, CC BY 3.0 — https://creativecommons.org/licenses/by/3.0/ ; {m['page']} . Використано короткий беззвучний фрагмент, змінено кадрування й колір, заблюрено сторонні логотипи. Інші офіційні архівні кадри Білого дому та Voice of America: Public domain, посилання наведено вище.\n"
text=text.replace('included у проєкті','додано до проєкту')
(O/'ABU-DHABI-SOURCES-AND-MEDIA.txt').write_text(text)
(P/'README.txt').write_text('ABU DHABI NEWS REELS • 04.11.2026\n\n58 seconds, 1080x1920, 30 fps, H264 Constrained Baseline. Original footage audio is never included. All documentary footage is visibly labelled archive with its year. No footage represents the future meeting.\n\nAUDIO: MUSIC.wav is separate. VOICEOVER.wav is digital silence, full length, starting at 00:00. Replace it with your own narration. The ready master has MUSIC and silent VOICEOVER as separate MP4 audio streams; editors may import only the default stream, so use the no-music version and separate MUSIC file for complete control. The project MLT has independent music/voice tracks.\n\nNo-music MP4 is completely silent. Import it into CapCut and add your own recording on a separate audio layer. You can add the provided instrumental music as another layer.\n\nRENDER: python render.py (requires FFmpeg/libass, Python/Pillow). The clips folder contains normalized, cleaned, silent documentary intervals. timeline.json, mask coordinates and normalize filter scripts document every source interval. map.py and map-coordinates.json document the geography. sources file contains source/license links and required CC BY credit for the publication description.\n')
