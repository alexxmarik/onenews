from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import subprocess,json
R=Path(__file__).parent;P=R/'project';O=R/'output';O.mkdir(exist_ok=True)
F='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
C=[
(0,5,'ПЕРЕГОВОРИ ПРО МИР\nНОВИЙ РАУНД\nВ АБУ-ДАБІ','Що відомо про анонсовану зустріч',52),
(5,9,'10–11 ЛИСТОПАДА\nАБУ-ДАБІ • ОАЕ','Анонс США • робочий рівень',51),
(9,12,'СТІВ ВІТКОФФ\nАНОНСУВАВ ПЕРЕГОВОРИ','Україна • США • Росія',45),
(12,18,'ЗУСТРІЧ КОМАНД\nЗА ПОСЕРЕДНИЦТВА США','Цей раунд — не саміт президентів',46),
(18,21.5,'ПРИПИНЕННЯ УДАРІВ\nПО ЕНЕРГЕТИЦІ','ПРІОРИТЕТ УКРАЇНИ • 1 / 4',48),
(21.5,25,'БЕЗПЕКА СУДНОПЛАВСТВА\nТА ЗЕРНОВИЙ КОРИДОР','ПРІОРИТЕТ УКРАЇНИ • 2 / 4',42),
(25,28.5,'БІЛЬШЕ ОБМІНІВ\nВІЙСЬКОВОПОЛОНЕНИМИ','ПРІОРИТЕТ УКРАЇНИ • 3 / 4',43),
(28.5,32,'ПІДГОТОВКА ЗУСТРІЧІ\nЛІДЕРІВ ЗА УЧАСТЮ ЄВРОПИ','ПРІОРИТЕТ УКРАЇНИ • 4 / 4',41),
(32,39,'РОСІЙСЬКУ ДЕЛЕГАЦІЮ\nОЧОЛИТЬ МЕДИНСЬКИЙ','За повідомленнями про заяву Кремля',46),
(39,45,'ПОЗИЦІЇ СТОРІН\nВІДРІЗНЯЮТЬСЯ','Розбіжності щодо завершення війни',51),
(45,51,'ЦЕЙ РАУНД — ПОПЕРЕДУ\nМИРНУ УГОДУ НЕ ОГОЛОШЕНО','Станом на 4 листопада 2026 року',40),
(51,58,'10–11 ЛИСТОПАДА\nЧИ СТАНЕ БЛИЖЧИМ\nСПРАВЕДЛИВИЙ МИР?','Абу-Дабі • Об’єднані Арабські Емірати',46)]
T=json.loads((P/'timeline.json').read_text());shots=T['shots']
def tm(s):return f'{int(s//3600)}:{int(s//60)%60:02}:{s%60:05.2f}'
head='''[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
ScaledBorderAndShadow: yes
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Main,DejaVu Sans,48,&H00FFFFFF,&H000000FF,&H0016240B,&H00000000,-1,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1
Style: Sub,DejaVu Sans,27,&H00E9E0D7,&H000000FF,&H0016240B,&H00000000,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
lines=[]
for a,b,title,sub,size in C:
 while max(ImageFont.truetype(F,size).getlength(x) for x in title.splitlines())>815:size-=1
 ss=32
 while ImageFont.truetype(F,ss).getlength(sub)>810:ss-=1
 title=title.replace('\n',r'\N')
 lines.append(f'Dialogue: 2,{tm(a)},{tm(b)},Main,,0,0,0,,{{\\move(90,1370,90,1340,0,220)\\fad(110,80)\\fs{size}}}{title}')
 lines.append(f'Dialogue: 2,{tm(a)},{tm(b)},Sub,,0,0,0,,{{\\pos(90,1575)\\fad(140,80)\\fs{ss}}}{sub}')
for shot in shots:
 a=shot['timeline_start'];b=a+shot['timeline_duration'];txt=shot['label'];fs=34
 while ImageFont.truetype(F,fs).getlength(txt)>830:fs-=1
 lines.append(f'Dialogue: 2,{tm(a)},{tm(b)},Sub,,0,0,0,,{{\\pos(82,343)\\fs{fs}\\fad(50,40)}}{txt}')
(P/'headlines.ass').write_text(head+'\n'.join(lines)+'\n')
# Readable native graphics; no media-source captions or channel links are rendered.
im=Image.new('RGBA',(1080,1920));d=ImageDraw.Draw(im)
for y in range(0,430):d.line((0,y,1080,y),fill=(3,10,25,round(185*(1-y/430))))
for y in range(1130,1920):d.line((0,y,1080,y),fill=(3,10,25,round(min(210,(y-1130)*.42))))
d.rounded_rectangle((64,214,218,274),radius=5,fill=(199,30,54,255));d.text((82,223),'NEWS',font=ImageFont.truetype(F,34),fill='white')
d.text((238,231),'ABU DHABI',font=ImageFont.truetype(F,27),fill='white')
d.text((754,232),'04.11.2026',font=ImageFont.truetype(F,27),fill='white')
d.rounded_rectangle((64,321,944,389),radius=7,fill=(4,17,37,224))
d.rounded_rectangle((64,1307,944,1635),radius=10,fill=(5,18,39,235));d.rectangle((64,1307,74,1635),fill=(212,35,59))
# Keep source and technical credits in the accompanying source list, not tiny screen text.
im.save(P/'layout.png')
(P/'ticker.txt').write_text('10–11 ЛИСТОПАДА • АБУ-ДАБІ   |   УКРАЇНА • США • РОСІЯ   |   АНОНСОВАНИЙ РАУНД ПЕРЕГОВОРІВ   |   ПОГОДЖЕНОЇ МИРНОЇ УГОДИ НЕ ОГОЛОШЕНО   |   ')
args=['ffmpeg','-v','warning','-y','-filter_complex_threads','1']
for i in range(len(shots)):args+=['-threads','1','-i',str(R/'clips'/f'{i:02d}.mp4')]
layout=len(shots);mp=layout+1
args+=['-loop','1','-i',str(P/'layout.png'),'-loop','1','-i',str(P/'map.png')]
g=[]
for i in range(len(shots)):g.append(f'[{i}:v]setpts=PTS-STARTPTS,fps=30,settb=1/30,format=yuv420p[v{i}]')
prev='v0'
for i in range(1,len(shots)):
 start=shots[i]['timeline_start'];new=f'x{i}';g.append(f'[{prev}][v{i}]xfade=transition=fade:duration=0.133333333:offset={start},fps=30,settb=1/30[{new}]');prev=new
# Map overlays are explanatory graphics, not alleged footage of the coming meeting.
g += [f'[{mp}:v]format=rgba,split=2[mapa][mapb]',
'[mapa]fade=t=in:st=5:d=0.24:alpha=1,fade=t=out:st=8.75:d=0.25:alpha=1[map1]',
'[mapb]fade=t=in:st=48:d=0.24:alpha=1,fade=t=out:st=50.75:d=0.25:alpha=1[map2]',
f'[{prev}][map1]overlay=100:515:enable=\'between(t,5,9)\'[geo1]',
"[geo1][map2]overlay=100:515:enable='between(t,48,51)'[geo2]",
f'[geo2][{layout}:v]overlay=0:0,ass={P}/headlines.ass[news]',
f"color=c=0xB41630:s=880x54:r=30:d=58,drawtext=fontfile={F}:textfile={P}/ticker.txt:fontsize=26:fontcolor=white:x=w-mod(t*100\\,text_w+w):y=(h-text_h)/2[ticker]",
'[news][ticker]overlay=64:1670,format=yuv420p[out]']
(P/'filter.ffscript').write_text(';\n'.join(g))
args+=['-filter_complex_script',str(P/'filter.ffscript'),'-map','[out]','-an','-frames:v','1740','-c:v','libx264','-profile:v','baseline','-level:v','4.0','-preset','fast','-crf','22','-maxrate','8M','-bufsize','16M','-threads','3','-pix_fmt','yuv420p','-movflags','+faststart',str(O/'ABU-DHABI-2026-11-04-picture.mp4')]
(P/'render-command.json').write_text(json.dumps(args,ensure_ascii=False,indent=2))
with (P/'render.log').open('w') as log:subprocess.run(args,stdout=log,stderr=log,check=True)
print('Picture rendered',flush=True)
