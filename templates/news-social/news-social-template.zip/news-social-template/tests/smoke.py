from pathlib import Path
import tempfile,shutil,json,subprocess,hashlib,wave,math,struct
from PIL import Image,ImageDraw
root=Path(__file__).resolve().parents[1]
def run(cmd,**kw):return subprocess.run(cmd,check=True,capture_output=True,text=True,**kw)
with tempfile.TemporaryDirectory(prefix='news-template-check-') as td:
 t=Path(td);shutil.copytree(root/'src',t/'src');shutil.copytree(root/'content',t/'content')
 for d in ['assets/branding','assets/audio','assets/media','out']:(t/d).mkdir(parents=True,exist_ok=True)
 def cli(*args,check=True):return subprocess.run([sys.executable,str(t/'src/render.py'),*args],capture_output=True,text=True,check=check)
 import sys
 report=json.loads(cli('--check',check=False).stdout)
 assert not report['passed'] and any('logo_top_right' in e for e in report['errors']) and any('logo_bottom_left' in e for e in report['errors'])
 # Test-only generated fixtures, kept in an isolated temporary directory.
 hashes={}
 for i,name in enumerate(['logo_top_right.png','logo_bottom_left.png']):
  p=t/'assets/branding'/name;im=Image.new('RGBA',(300,90),(35,160,210,230) if i==0 else (210,120,35,230));ImageDraw.Draw(im).text((10,30),'TEST FIXTURE',fill='white');im.save(p);hashes[name]=hashlib.sha256(p.read_bytes()).hexdigest()
 im=Image.new('RGB',(1200,500),'#35778f');ImageDraw.Draw(im).text((20,20),'TEST IMAGE',fill='white');im.save(t/'assets/media/test.png')
 run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi','-i','testsrc2=size=640x360:rate=30:duration=1','-c:v','libx264','-pix_fmt','yuv420p',str(t/'assets/media/test.mp4')])
 with wave.open(str(t/'assets/audio/test.wav'),'wb') as f:
  f.setnchannels(1);f.setsampwidth(2);f.setframerate(48000)
  f.writeframes(b''.join(struct.pack('<h',round(1200*math.sin(2*math.pi*220*n/48000))) for n in range(48000)))
 geo={'type':'FeatureCollection','features':[{'type':'Feature','properties':{},'geometry':{'type':'Polygon','coordinates':[[[0,0],[2,0],[2,2],[0,2],[0,0]]]}}]}
 (t/'assets/media/test.geojson').write_text(json.dumps(geo))
 scenes=[]
 for i,extra in enumerate([
 {'media':{'type':'image','path':'assets/media/test.png','rights_confirmed':True,'credit':'Test fixture'}},
 {'media':{'type':'video','path':'assets/media/test.mp4','rights_confirmed':True,'credit':'Test fixture','archive':True}},
 {'graphic':{'type':'metric','value':'ТЕСТ','label':'Не новинні дані'}},
 {'graphic':{'type':'bars','items':[{'label':'Тест А','value':0},{'label':'Тест Б','value':1}]}},
 {'graphic':{'type':'map','geojson':'assets/media/test.geojson','bounds':[-1,-1,3,3],'markers':[{'lon':1,'lat':1,'label':'ТЕСТ'}]}}
 ]):scenes.append(dict(duration=1,kicker='ТЕСТ',headline='Технічна перевірка',verified=True,source='Synthetic test fixture, not news',**extra))
 cfg={'fps':30,'editorial_verified':True,'audio_mode':'music','music':'assets/audio/test.wav','music_rights_confirmed':True,'subtitles':'content/test.srt','scenes':scenes}
 (t/'content/test.srt').write_text('\n\n'.join(f'{i+1}\n00:00:0{i},000 --> 00:00:0{i+1},000\nТест. Не для публікації.' for i in range(5)))
 (t/'content/test.json').write_text(json.dumps(cfg,ensure_ascii=False))
 cli('--config','content/test.json','--output','out/test.mp4')
 j=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(t/'out/test.mp4')]).stdout)
 v=next(s for s in j['streams'] if s['codec_type']=='video');assert (v['width'],v['height'])==(1080,1920) and v['r_frame_rate']=='30/1' and v['nb_frames']=='150'
 assert sum(s['codec_type']=='audio' for s in j['streams'])==1
 run(['ffmpeg','-hide_banner','-loglevel','error','-i',str(t/'out/test.mp4'),'-f','null','-'])
 for name,h in hashes.items():assert hashlib.sha256((t/'assets/branding'/name).read_bytes()).hexdigest()==h
 # Production export must reject a voice input, even if a path is supplied.
 cfg['voiceover']='assets/audio/test.wav';(t/'content/test.json').write_text(json.dumps(cfg))
 r=cli('--config','content/test.json','--check',check=False);assert r.returncode==2 and 'Voiceover is disabled' in r.stdout
 print('PASS: missing originals block publication; image/video/archive/metric/chart/map render; music-only audio; original PNG hashes unchanged; voice input rejected; 1080×1920/30fps/H.264 full decoding.')
