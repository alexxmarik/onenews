#!/usr/bin/env python3
"""Optional FUTURE step: attach a user-supplied recording; never synthesize voice."""
from pathlib import Path
import argparse,subprocess
ap=argparse.ArgumentParser();ap.add_argument('--video',required=True);ap.add_argument('--voice',required=True);ap.add_argument('--output',required=True);args=ap.parse_args()
v,a,o=map(Path,[args.video,args.voice,args.output])
if not v.is_file() or not a.is_file():ap.error('Provide existing video and your own voice recording')
if o.resolve() in [v.resolve(),a.resolve()]:ap.error('Output must be a new file')
# Voice replaces any existing audio; keep music as a separate stem for your editor.
subprocess.run(['ffmpeg','-hide_banner','-i',str(v),'-i',str(a),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-af','apad','-shortest','-movflags','+faststart',str(o)],check=True)
