#!/usr/bin/env python3
"""Offline, configurable FFmpeg social-news compositor. No news gathering or TTS."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageOps
import argparse,json,re,hashlib,subprocess,sys,math
import graphics
ROOT=Path(__file__).resolve().parents[1]
W,H,FPS=1080,1920,30
BOXES={'top_logo':(652,225,932,285),'bottom_logo':(64,1440,344,1500),'media':(64,580,932,1080),'caption':(64,1175,932,1415)}
FONT_DIR=Path('/usr/share/fonts/truetype/dejavu');FC={}
def font(size,bold=False):
 key=(size,bold)
 if key not in FC:FC[key]=ImageFont.truetype(str(FONT_DIR/('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf')),size)
 return FC[key]
def wrap(text,size,width,bold=False):
 lines=[]
 for paragraph in text.split('\n'):
  line=''
  for word in paragraph.split():
   if font(size,bold).getlength(word)>width:raise ValueError('Word exceeds available width: '+word)
   candidate=(line+' '+word).strip()
   if font(size,bold).getlength(candidate)>width and line:lines.append(line);line=word
   else:line=candidate
  if line:lines.append(line)
 return lines

def resolve(value):return (ROOT/value).resolve() if value else None
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def probe(path):
 return json.loads(subprocess.run(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(path)],check=True,capture_output=True,text=True).stdout)
def stamp(s):
 m=re.fullmatch(r'(\d{2,}):(\d{2}):(\d{2})[,.](\d{3})',s.strip())
 if not m:raise ValueError('Invalid subtitle timestamp: '+s)
 h,mi,se,ms=map(int,m.groups());assert mi<60 and se<60
 return h*3600+mi*60+se+ms/1000

def load_srt(path):
 blocks=re.split(r'\n\s*\n',path.read_text(encoding='utf-8-sig').strip());result=[]
 for block in blocks:
  ls=block.splitlines()
  if not ls:continue
  if ls[0].strip().isdigit():ls=ls[1:]
  if not ls or '-->' not in ls[0]:raise ValueError('Invalid SRT block: '+block[:70])
  a,b=ls[0].split('-->');start,end=stamp(a),stamp(b)
  text=' '.join(x.strip() for x in ls[1:]).strip()
  if not text or end<=start:raise ValueError('Empty or negative subtitle')
  if result and start<result[-1]['end']-.0001:raise ValueError('Overlapping subtitles')
  result.append(dict(start=start,end=end,text=text))
 return result

def logos_status():
 rows=[]
 for name in ['logo_top_right.png','logo_bottom_left.png']:
  p=ROOT/'assets/branding'/name;row=dict(file=str(p),exists=p.is_file())
  if p.is_file():
   with Image.open(p) as im:
    if im.format!='PNG':raise ValueError(name+' must be an original PNG file')
    im.verify()
   with Image.open(p) as im:row.update(width=im.width,height=im.height,mode=im.mode,sha256=digest(p))
  rows.append(row)
 return rows

def validate(config,preview=False):
 errors=[];warnings=[];total=sum(float(s['duration']) for s in config.get('scenes',[]))
 if total<=0:errors.append('At least one positive-duration scene is required')
 if config.get('fps',FPS)!=FPS:errors.append('This template uses exactly 30 FPS')
 if not preview and not config.get('editorial_verified'):errors.append('editorial_verified must be true after human fact-checking')
 logos=logos_status()
 for row in logos:
  if not row['exists']:
   (warnings if preview else errors).append('Missing original logo: '+row['file'])
 for i,s in enumerate(config.get('scenes',[])):
  if s['duration']<=0:errors.append(f'Scene {i+1}: invalid duration')
  if not preview and not s.get('verified'):errors.append(f'Scene {i+1}: verified must be true')
  if not preview and not s.get('source'):errors.append(f'Scene {i+1}: source reference required')
  if len(wrap(s.get('headline',''),48,868,True))>3:errors.append(f'Scene {i+1}: headline exceeds 3 lines')
  if not s.get('headline'):errors.append(f'Scene {i+1}: headline is required')
  if len(wrap(s.get('body',''),32,812,False))>7:errors.append(f'Scene {i+1}: body exceeds 7 lines')
  graphic=s.get('graphic')
  if graphic and s.get('media'):errors.append(f'Scene {i+1}: choose media OR graphic')
  errors.extend(f'Scene {i+1}: '+e for e in graphics.check(graphic,resolve))
  media=s.get('media')
  if media:
   p=resolve(media.get('path'))
   if not p or not p.is_file():errors.append(f'Scene {i+1}: media file missing')
   elif media.get('type')=='image':
    try:
     with Image.open(p) as im:im.verify()
    except Exception as e:errors.append(f'Scene {i+1}: image invalid: {e}')
   elif media.get('type')=='video':
    j=probe(p);v=[a for a in j['streams'] if a['codec_type']=='video']
    if not v:errors.append(f'Scene {i+1}: media has no video stream')
    if float(j['format'].get('duration',0))-float(media.get('in',0))<s['duration']-.05:errors.append(f'Scene {i+1}: video clip too short; no automatic footage looping')
   else:errors.append(f'Scene {i+1}: media.type must be image or video')
   if not preview and not media.get('rights_confirmed'):errors.append(f'Scene {i+1}: confirm media rights')
   if not preview and not media.get('credit'):errors.append(f'Scene {i+1}: media credit is required')
 if config.get('voiceover'):
  errors.append('Voiceover is disabled in this template. Add your recording later in a separate editing step.')
 music=resolve(config.get('music'))
 if music:
  if not music.is_file():errors.append('Music file missing: '+str(music))
  else:
   j=probe(music)
   if not any(s['codec_type']=='audio' for s in j['streams']):errors.append('Music file has no audio stream')
  if not preview and not config.get('music_rights_confirmed'):errors.append('Confirm music rights before using music')
 if config.get('audio_mode','silent') not in ['silent','music']:
  errors.append('audio_mode must be silent or music')
 if config.get('audio_mode')=='music' and not music:errors.append('Music mode requires a supplied instrumental music file')
 caps=[];path=resolve(config.get('subtitles'))
 if path and path.is_file():
  caps=load_srt(path)
  for c in caps:
   if c['end']>total+.001:errors.append('Subtitle extends beyond timeline')
   if len(wrap(c['text'],38,812,True))>4:errors.append('Subtitle exceeds 4 safe-area lines: '+c['text'])
 else:errors.append('SRT file missing')
 if not caps:errors.append('At least one subtitle is required')
 report=dict(passed=not errors,preview=preview,voiceover=False,audio_mode=config.get('audio_mode','silent'),duration=total,width=W,height=H,fps=FPS,logos=logos,errors=errors,warnings=warnings,safe_area=[64,220,932,1515],overlay_boxes=BOXES)
 return report,caps

class Timeline:
 def __init__(self,config,caps,preview=False):
  self.config=config;self.caps=caps;self.preview=preview;self.total=sum(s['duration'] for s in config['scenes']);self.decoder=None;self.index=None
  self.bg=Image.new('RGB',(W,H),'#091623');d=ImageDraw.Draw(self.bg)
  for x in range(0,W,80):d.line((x,0,x,H),fill='#102b3d')
  for y in range(0,H,80):d.line((0,y,W,y),fill='#102b3d')
  d.rectangle((64,233,73,255),fill='#f14a59')
  d.text((87,228),config.get('brand_label','НОВИНИ'),font=font(23,True),fill='#edf2f4')
  d.line((64,300,932,300),fill='#355367',width=2)
  if preview:d.text((64,1640),'ТЕХНІЧНИЙ ПЕРЕГЛЯД • НЕ ДЛЯ ПУБЛІКАЦІЇ',font=font(22,True),fill='#f5c25c')
  self.brand=[]
  for name,key in [('logo_top_right.png','top_logo'),('logo_bottom_left.png','bottom_logo')]:
   p=ROOT/'assets/branding'/name;box=BOXES[key]
   if p.is_file():
    # Preserve all pixels, alpha, colors and aspect ratio. Never crop, redraw or key backgrounds.
    with Image.open(p) as source:im=source.convert('RGBA');self.brand.append((ImageOps.contain(im,(box[2]-box[0],box[3]-box[1]),Image.Resampling.LANCZOS),box))
   elif preview:self.brand.append((None,box))
  self.layers=[];self.images={};self.graphics={}
  for i,s in enumerate(config['scenes']):
   layer=Image.new('RGBA',(W,H));d=ImageDraw.Draw(layer);y=334
   d.text((64,y),s.get('kicker',''),font=font(23,True),fill='#66b7fb');y+=48
   for line in wrap(s['headline'],48,868,True):d.text((64,y),line,font=font(48,True),fill='#f5f7f4');y+=58
   d.rounded_rectangle(BOXES['media'],20,fill='#102a3c',outline='#34566a',width=2)
   media=s.get('media')
   if s.get('graphic'):self.graphics[i]=graphics.Graphic(s['graphic'],resolve,font,wrap)
   if media and media['type']=='image':
    with Image.open(resolve(media['path'])) as raw:im=ImageOps.exif_transpose(raw).convert('RGBA');im=ImageOps.contain(im,(868,500),Image.Resampling.LANCZOS)
    self.images[i]=im
   if not media:
    yy=610
    for line in wrap(s.get('body','МІСЦЕ ДЛЯ ПЕРЕВІРЕНИХ МАТЕРІАЛІВ'),32,812):d.text((92,yy),line,font=font(32),fill='#b7cbd7');yy+=44
   if media:
    credit=media.get('credit','');credit=credit if len(credit)<90 else credit[:87]+'…'
    d.text((64,1100),credit,font=font(18),fill='#9bb2c0')
    if media.get('archive'):d.text((76,590),'АРХІВ',font=font(27,True),fill='#ffd76d')
   self.layers.append(layer)
 def close_decoder(self):
  if self.decoder:
   self.decoder.stdout.close();self.decoder.terminate();self.decoder.wait();self.decoder=None
 def close(self):self.close_decoder()
 def frame(self,t):
  start=0
  for idx,s in enumerate(self.config['scenes']):
   if start<=t<start+s['duration']:break
   start+=s['duration']
  if idx!=self.index:
   self.close_decoder();self.index=idx;media=s.get('media')
   if media and media['type']=='video':
    vf='fps=30,scale=868:500:force_original_aspect_ratio=decrease,pad=868:500:(ow-iw)/2:(oh-ih)/2:color=0x102a3c'
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-ss',str(media.get('in',0)),'-i',str(resolve(media['path'])),'-vf',vf,'-an','-threads','1','-f','rawvideo','-pix_fmt','rgb24','pipe:1']
    self.decoder=subprocess.Popen(cmd,stdout=subprocess.PIPE)
  im=self.bg.copy().convert('RGBA');layer=self.layers[idx].copy();local=t-start
  opacity=max(0,min(1,local/.4,(start+s['duration']-t)/.25))
  if opacity<1:layer.putalpha(layer.getchannel('A').point(lambda a:int(a*opacity)))
  im.alpha_composite(layer,(0,int((1-opacity)*12)))
  if idx in self.images:
   pic=self.images[idx];im.alpha_composite(pic,(64+(868-pic.width)//2,580+(500-pic.height)//2))
  if self.decoder:
   expected=868*500*3;data=self.decoder.stdout.read(expected)
   if len(data)!=expected:raise RuntimeError('Video decoder ran out of frames; check clip duration')
   im.alpha_composite(Image.frombytes('RGB',(868,500),data).convert('RGBA'),(64,580))
  if idx in self.graphics:im.alpha_composite(self.graphics[idx].frame(local),(64,580))
  d=ImageDraw.Draw(im)
  # Credit/archive label must remain above inserted media, not below its pixel layer.
  media=s.get('media')
  if media and media.get('archive'):d.rectangle((76,590,212,635),fill='#091623');d.text((84,594),'АРХІВ',font=font(26,True),fill='#ffd76d')
  c=next((c for c in self.caps if c['start']<=t<c['end']),None)
  if c:
   d.rounded_rectangle(BOXES['caption'],16,fill='#edf2f4');d.rectangle((64,1195,69,1395),fill='#58acfa')
   ls=wrap(c['text'],38,812,True);y=1175+(240-len(ls)*48)//2-3
   for line in ls:d.text((90,y),line,font=font(38,True),fill='#112432');y+=48
  # Branding is composited LAST, so it cannot disappear during transitions.
  for logo,box in self.brand:
   if logo is None:
    d.rectangle(box,outline='#8ca0ad',width=2);d.text((box[0]+10,box[1]+18),'МІСЦЕ ДЛЯ ОРИГІНАЛУ',font=font(16),fill='#8ca0ad')
   else:im.alpha_composite(logo,(box[0]+(box[2]-box[0]-logo.width)//2,box[1]+(box[3]-box[1]-logo.height)//2))
  d=ImageDraw.Draw(im);d.line((64,1530,932,1530),fill='#294659',width=3);d.line((64,1530,64+int(868*t/self.total),1530),fill='#58acfa',width=3)
  return im.convert('RGB')

def render(config,preview,output):
 report,caps=validate(config,preview);output.parent.mkdir(parents=True,exist_ok=True)
 (output.parent/(output.stem+'-preflight.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2))
 if not report['passed']:raise ValueError('\n'.join(report['errors']))
 total=report['duration'];frames=round(total*FPS)
 if abs(frames/FPS-total)>.001:raise ValueError('Timeline duration must align with 30 FPS')
 cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-video_size','1080x1920','-framerate','30','-i','pipe:0']
 music=resolve(config.get('music'))
 audio=bool(config.get('audio_mode')=='music' and music and music.is_file())
 if audio:
  cmd+=['-stream_loop','-1','-i',str(music),'-map','0:v:0','-map','1:a:0','-filter:a','volume=0.12,alimiter=limit=0.8:level=false','-c:a','aac','-b:a','192k','-ar','48000']
 else:cmd+=['-map','0:v:0','-an']
 cmd+=['-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-threads','3','-t',str(total),'-movflags','+faststart',str(output)]
 (output.parent/(output.stem+'-ffmpeg.json')).write_text(json.dumps(cmd,indent=2));timeline=Timeline(config,caps,preview);p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 try:
  for n in range(frames):
   p.stdin.write(timeline.frame(n/FPS).tobytes())
  p.stdin.close();code=p.wait()
  if code:raise RuntimeError('FFmpeg failed: '+str(code))
 except BaseException:p.kill();raise
 finally:timeline.close()
 for logo in report['logos']:
  if logo['exists']:assert digest(Path(logo['file']))==logo['sha256'],'Original logo was modified'
 print('CREATED',output,flush=True)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--config',default='content/story.json');ap.add_argument('--preview',action='store_true');ap.add_argument('--check',action='store_true');ap.add_argument('--check-assets',action='store_true');ap.add_argument('--output',default='out/news.mp4');args=ap.parse_args()
 if args.check_assets:print(json.dumps(logos_status(),ensure_ascii=False,indent=2));return
 config=json.loads(resolve(args.config).read_text())
 if args.check:
  report,_=validate(config,args.preview);print(json.dumps(report,ensure_ascii=False,indent=2));sys.exit(0 if report['passed'] else 2)
 render(config,args.preview,resolve(args.output))
if __name__=='__main__':
 try:main()
 except Exception as e:print('ERROR:',str(e),file=sys.stderr);sys.exit(2)
