"""Editable graphics: no built-in news data or external requests."""
from pathlib import Path
from PIL import Image,ImageDraw
import json,math

def check(g,resolve):
 errors=[]
 if not g:return errors
 kind=g.get('type')
 if kind=='metric':
  if not str(g.get('value','')).strip():errors.append('Metric value is required')
 elif kind=='bars':
  items=g.get('items',[])
  if not 1<=len(items)<=4:errors.append('Bar chart supports 1–4 items')
  for item in items:
   if not isinstance(item.get('value'),(int,float)) or not math.isfinite(item['value']) or item['value']<0:errors.append('Chart values must be finite and nonnegative')
 elif kind=='map':
  p=resolve(g.get('geojson'))
  if not p or not p.is_file():errors.append('Supply a verified GeoJSON map file')
  else:
   try:
    j=json.loads(p.read_text());assert j['type']=='FeatureCollection';assert j.get('features')
   except Exception:errors.append('Map must be a nonempty GeoJSON FeatureCollection')
  b=g.get('bounds',[])
  if len(b)!=4 or not all(isinstance(x,(float,int)) and math.isfinite(x) for x in b) or b[0]>=b[2] or b[1]>=b[3]:errors.append('Map bounds must be [west,south,east,north]')
 else:errors.append('graphic.type must be metric, bars or map')
 return errors

class Graphic:
 def __init__(self,g,resolve,font,wrap):
  self.g=g;self.font=font;self.wrap=wrap;self.features=[]
  if g['type']=='map':self.features=json.loads(resolve(g['geojson']).read_text())['features']
 def frame(self,t):
  im=Image.new('RGBA',(868,500),'#102a3c');d=ImageDraw.Draw(im);g=self.g;kind=g['type'];f=self.font;progress=max(0,min(1,t/1.8))
  if kind=='metric':
   value=str(g['value']);size=112
   while f(size,True).getlength(value)>804 and size>32:size-=2
   if f(size,True).getlength(value)>804:raise ValueError('Metric value too long')
   d.text((32,70),value,font=f(size,True),fill='#f0f5f7')
   d.line((32,225,32+int(780*progress),225),fill='#58acfa',width=5)
   yy=260
   for line in self.wrap(g.get('label',''),32,804,True)[:3]:d.text((32,yy),line,font=f(32,True),fill='#b7cbd7');yy+=43
  elif kind=='bars':
   items=g['items'];maximum=max([float(i['value']) for i in items]+[1]);yy=38
   for item in items:
    label=str(item.get('label',''))
    if f(27,True).getlength(label)>780:raise ValueError('Chart label too long')
    d.text((32,yy),label,font=f(27,True),fill='#edf3f6')
    width=int(600*float(item['value'])/maximum*progress)
    d.rounded_rectangle((32,yy+46,632,yy+76),7,fill='#254356')
    if width>0:d.rounded_rectangle((32,yy+46,32+width,yy+76),7,fill='#58acfa')
    val=str(item['value'])+str(g.get('unit',''))
    if f(26,True).getlength(val)>165:raise ValueError('Chart value/unit too long')
    d.text((660,yy+38),val,font=f(26,True),fill='#edf3f6');yy+=108
  else:
   west,south,east,north=g['bounds'];lat=(south+north)/2;cos=max(.1,math.cos(math.radians(lat)));sx=(east-west)*cos;sy=north-south
   scale=min(780/sx,400/sy);ox=(868-sx*scale)/2;oy=(500-sy*scale)/2
   def project(lon,lat):return (ox+(lon-west)*cos*scale,500-oy-(lat-south)*scale)
   for feat in self.features:
    geo=feat.get('geometry') or {};coords=geo.get('coordinates',[]);kind=geo.get('type')
    polys=coords if kind=='MultiPolygon' else [coords] if kind=='Polygon' else []
    for polygon in polys:
     if polygon:
      d.polygon([project(*point[:2]) for point in polygon[0]],fill='#285371',outline='#91b7cd',width=2)
      for hole in polygon[1:]:d.polygon([project(*point[:2]) for point in hole],fill='#102a3c')
   for marker in g.get('markers',[]):
    lon,lat=marker['lon'],marker['lat']
    if not (west<=lon<=east and south<=lat<=north):raise ValueError('Map marker outside bounds')
    x,y=project(lon,lat);rr=7+int(5*(math.sin(t*2)*.5+.5));d.ellipse((x-rr,y-rr,x+rr,y+rr),fill='#ffd75e')
    label=marker.get('label','');length=f(25,True).getlength(label);xx=max(12,min(x+20,856-length));yy=max(12,min(y-35,460))
    if length>820:raise ValueError('Map marker label too long')
    d.text((xx,yy),label,font=f(25,True),fill='#f4f7f8',stroke_width=2,stroke_fill='#102a3c')
  return im
